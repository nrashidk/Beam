# InvoLinks - Company Edit & Invoice Creation Files

## Issue Reported
`spawn ENAMETOOLONG` error on Windows system during build/run

## Files Included

### Frontend Files
1. **CompanySettings.jsx** - Full page company profile editor
2. **CompanyInfoEditDialog.jsx** - Modal dialog for quick edits
3. **CreateInvoice.jsx** - Invoice creation form with VAT compliance
4. **CompanyBranding.jsx** - Logo and stamp upload
5. **api.js** - API client configuration and helpers

### Backend Files
6. **main_company_endpoint.py** - Company profile update endpoint
7. **main_invoice_endpoint_part1.py** - Invoice creation helpers
8. **main_invoice_endpoint_part2.py** - Invoice creation endpoint

### Configuration Files
9. **vite.config.js** - Vite build configuration (optimized)
10. **package.json** - Dependencies and scripts
11. **.gitignore** - Excluded files and folders

## API Endpoints

### Company Profile Update
- **Endpoint**: `PUT /company/profile`
- **Frontend**: CompanySettings.jsx (line 91), CompanyInfoEditDialog.jsx (line 70)
- **Backend**: main.py (lines 2978-3032)
- **Fields**: legal_name, phone, website, address_line1, address_line2, city, emirate, po_box

### Invoice Creation
- **Endpoint**: `POST /invoices`
- **Frontend**: CreateInvoice.jsx (line 142)
- **Backend**: main.py (lines 4005-4242)
- **Features**: VAT detection, tax codes (SR/ZR/ES/RC/OP), line items, customer details

## Current Status
✅ All files committed to Git
✅ Build optimizations applied (sourcemaps disabled)
✅ No uncommitted files in Replit workspace
⚠️ ENAMETOOLONG error happening on external Windows system

## Recommendations for External System
1. Move project to shorter path (e.g., C:\dev\involinks)
2. Delete node_modules and reinstall
3. Enable Windows long paths
4. Commit any uncommitted files on that system
5. Clear build caches (.vite, dist folders)

## Project Statistics
- Source Files: 212 JS/JSX files
- Dependencies: 16 packages
- Node Modules: 205 MB
- Build Output: 1.17 MB (gzipped 320 KB)
- Build Time: 7-15 seconds

---
Generated: November 3, 2025
