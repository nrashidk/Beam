# Backend Endpoint: Company Profile Update
# File: main.py (lines 2978-3032)

from fastapi import HTTPException, Depends
from datetime import datetime

@app.put("/company/profile", tags=["Companies"])
def update_company_profile(
    payload: CompanyProfileUpdateRequest,
    current_user: UserDB = Depends(get_current_user_from_header),
    db: Session = Depends(get_db)
):
    """Update company profile (Company Admin only)"""
    if current_user.role not in [Role.COMPANY_ADMIN, Role.SUPER_ADMIN]:
        raise HTTPException(403, "Only company admins can update company profile")
    
    if not current_user.company_id:
        raise HTTPException(400, "User is not associated with a company")
    
    company = db.get(CompanyDB, current_user.company_id)
    if not company:
        raise HTTPException(404, "Company not found")
    
    # Update fields if provided
    if payload.legal_name is not None:
        company.legal_name = payload.legal_name
    if payload.phone is not None:
        company.phone = payload.phone
    if payload.website is not None:
        company.website = payload.website
    if payload.address_line1 is not None:
        company.address_line1 = payload.address_line1
    if payload.address_line2 is not None:
        company.address_line2 = payload.address_line2
    if payload.city is not None:
        company.city = payload.city
    if payload.emirate is not None:
        company.emirate = payload.emirate
    if payload.po_box is not None:
        company.po_box = payload.po_box
    
    company.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(company)
    
    return {
        "success": True,
        "message": "Company profile updated successfully",
        "company": {
            "id": company.id,
            "legal_name": company.legal_name,
            "email": company.email,
            "phone": company.phone,
            "website": company.website,
            "address_line1": company.address_line1,
            "address_line2": company.address_line2,
            "city": company.city,
            "emirate": company.emirate,
            "po_box": company.po_box
        }
    }
