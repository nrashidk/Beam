    __tablename__ = "companies"
    id = Column(String, primary_key=True)
    legal_name = Column(String, nullable=True)
    country = Column(String, default="AE")
    status = Column(SQLEnum(CompanyStatus), default=CompanyStatus.PENDING_REVIEW)
    trn = Column(String, nullable=True)
    
    # VAT Registration (Opt-In Model - Phase 1)
    vat_enabled = Column(Boolean, default=False)  # Toggle for VAT registration
    vat_registration_date = Column(Date, nullable=True)  # When business became VAT-registered
    vat_certificate_path = Column(String, nullable=True)  # Path to uploaded VAT certificate PDF
    
    # MFA (Multi-Factor Authentication) fields - Article 9.1 compliance
    mfa_enabled = Column(Boolean, default=False)
    mfa_method = Column(String, nullable=True)  # 'totp' or 'email'
    mfa_secret = Column(String, nullable=True)  # Base32 TOTP secret
    mfa_backup_codes = Column(Text, nullable=True)  # JSON array of hashed codes
    mfa_enrolled_at = Column(DateTime, nullable=True)
    mfa_last_verified_at = Column(DateTime, nullable=True)

    # Registration fields
    business_type = Column(String, nullable=True)
    business_activity = Column(String, nullable=True)
    registration_number = Column(String, nullable=True)
    registration_date = Column(Date, nullable=True)
    email = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    website = Column(String, nullable=True)

    # Address
    address_line1 = Column(String, nullable=True)
    address_line2 = Column(String, nullable=True)
    city = Column(String, nullable=True)
    emirate = Column(String, nullable=True)
    po_box = Column(String, nullable=True)

    # Authorized person
    authorized_person_name = Column(String, nullable=True)
    authorized_person_title = Column(String, nullable=True)
    authorized_person_email = Column(String, nullable=True)
