    }

@app.post("/invoices", tags=["Invoices"], response_model=InvoiceOut)
def create_invoice(
    payload: InvoiceCreate,
    current_user: UserDB = Depends(get_current_user_from_header),
    db: Session = Depends(get_db)
):
    """Create a new invoice"""
    # Get company
    company = db.query(CompanyDB).filter(CompanyDB.id == current_user.company_id).first()
    if not company:
        raise HTTPException(404, "Company not found")
    
    # Only require TRN when VAT is enabled
    if company.vat_enabled and not company.trn:
        raise HTTPException(400, "Company TRN is required to issue VAT invoices. Please enable VAT in settings first.")
    
    # Check trial limits (100 invoices OR 30 days, whichever comes first)
    if company.trial_status == "ACTIVE" and company.trial_start_date:
        days_elapsed = (datetime.utcnow() - company.trial_start_date).days
        trial_days_remaining = max(0, 30 - days_elapsed)
        trial_invoices_remaining = max(0, 100 - company.trial_invoice_count)
        
        # Check if trial expired
        if trial_days_remaining == 0:
            company.trial_status = "EXPIRED"
            company.trial_ended_at = datetime.utcnow()
            db.commit()
            raise HTTPException(
                403,
                "Free trial expired (30 days). Please subscribe to continue creating invoices."
            )
        
        if trial_invoices_remaining == 0:
            company.trial_status = "EXPIRED"
            company.trial_ended_at = datetime.utcnow()
            db.commit()
            raise HTTPException(
                403,
                "Free trial expired (100 invoices used). Please subscribe to continue creating invoices."
            )
    
    # Check if trial already expired
    if company.trial_status == "EXPIRED":
        # Check if they have an active subscription
        active_subscription = db.query(SubscriptionDB).filter(
            SubscriptionDB.company_id == company.id,
            SubscriptionDB.status == "ACTIVE"
        ).first()
        
        if not active_subscription:
            raise HTTPException(
                403,
                "Free trial expired. Please subscribe to continue creating invoices."
            )
    
    # Initialize trial if this is the first invoice
    if company.trial_status is None:
        company.trial_status = "ACTIVE"
        company.trial_start_date = datetime.utcnow()
        company.trial_invoice_count = 0
        db.commit()
    
    # Generate invoice number
    invoice_id = f"inv_{uuid4().hex[:12]}"
    invoice_number = generate_invoice_number(company.id, db)
    
    # Calculate totals
    subtotal = 0.0
    total_tax = 0.0
    tax_by_category = {}  # For tax breakdowns
    
    # Parse dates
    from datetime import datetime as dt
    issue_date = dt.fromisoformat(payload.issue_date).date()
    due_date = dt.fromisoformat(payload.due_date).date() if payload.due_date else None
    
    # Create invoice
    invoice = InvoiceDB(
        id=invoice_id,
        company_id=company.id,
        invoice_number=invoice_number,
        invoice_type=payload.invoice_type,
        status=InvoiceStatus.DRAFT,
        issue_date=issue_date,
        due_date=due_date,
        currency_code=payload.currency_code,
        
        # Supplier (from company)
        supplier_trn=company.trn,
        supplier_name=company.legal_name or company.email,
        supplier_address=f"{company.address_line1 or ''} {company.address_line2 or ''}".strip() or None,
        supplier_city=company.city,
        supplier_country="AE",
        supplier_peppol_id=company.trn[:10] if company.trn else None,  # First 10 digits of TRN as TIN
        
        # Customer
        customer_trn=payload.customer_trn,
        customer_name=payload.customer_name,
        customer_email=payload.customer_email,
        customer_address=payload.customer_address,
        customer_city=payload.customer_city,
        customer_country=payload.customer_country,
        customer_peppol_id=payload.customer_peppol_id,
        
        payment_terms=payload.payment_terms,
        payment_due_days=payload.payment_due_days,
        invoice_notes=payload.invoice_notes,
        reference_number=payload.reference_number,
        preceding_invoice_id=payload.preceding_invoice_id,
        credit_note_reason=payload.credit_note_reason,
        
        share_token=f"share_{uuid4().hex[:16]}"
    )
    
    db.add(invoice)
    db.flush()  # Get invoice ID
    
    # Create line items
    for idx, line_item in enumerate(payload.line_items, 1):
        totals = calculate_line_item_totals(line_item)
        
        line_db = InvoiceLineItemDB(
            id=f"line_{uuid4().hex[:12]}",
            invoice_id=invoice.id,
            line_number=idx,
            item_name=line_item.item_name,
            item_description=line_item.item_description,
            item_code=line_item.item_code,
            quantity=line_item.quantity,
            unit_code=line_item.unit_code,
            unit_price=line_item.unit_price,
            line_extension_amount=totals["line_extension_amount"],
            tax_category=line_item.tax_category,
            tax_percent=line_item.tax_percent,
            tax_code=line_item.tax_code,  # Save UAE tax code
            tax_amount=totals["tax_amount"],
            line_total_amount=totals["line_total_amount"]
        )
        db.add(line_db)
        
        subtotal += totals["line_extension_amount"]
        total_tax += totals["tax_amount"]
        
        # Aggregate tax by category
        key = (line_item.tax_category, line_item.tax_percent)
        if key not in tax_by_category:
            tax_by_category[key] = {"taxable": 0.0, "tax": 0.0}
        tax_by_category[key]["taxable"] += totals["line_extension_amount"]
        tax_by_category[key]["tax"] += totals["tax_amount"]
    
    # Create tax breakdowns
    for (category, percent), amounts in tax_by_category.items():
        tax_breakdown = InvoiceTaxBreakdownDB(
            id=f"tax_{uuid4().hex[:12]}",
            invoice_id=invoice.id,
            tax_category=category,
            taxable_amount=round(amounts["taxable"], 2),
            tax_percent=percent,
            tax_amount=round(amounts["tax"], 2)
        )
        db.add(tax_breakdown)
    
    # Update invoice totals
    invoice.subtotal_amount = round(subtotal, 2)
    invoice.tax_amount = round(total_tax, 2)
    invoice.total_amount = round(subtotal + total_tax, 2)
    invoice.amount_due = round(subtotal + total_tax, 2)
    
    # VAT Compliance: Auto-classify invoice type based on amount and company VAT status (Phase 1)
    from decimal import Decimal
    invoice.invoice_classification = classify_invoice_type(
        total_amount=Decimal(str(invoice.total_amount)),
        vat_enabled=company.vat_enabled or False
    )
    
    # Increment trial invoice count if in trial
    if company.trial_status == "ACTIVE":
        company.trial_invoice_count += 1
    
    # Invoice created as DRAFT - use /issue endpoint to generate XML and finalize
    db.commit()
    db.refresh(invoice)
    
    # Format response
    return InvoiceOut(
        id=invoice.id,
        company_id=invoice.company_id,
        invoice_number=invoice.invoice_number,
        invoice_type=invoice.invoice_type,
        status=invoice.status,
        issue_date=invoice.issue_date.isoformat(),
        due_date=invoice.due_date.isoformat() if invoice.due_date else None,
        currency_code=invoice.currency_code,
        supplier_trn=invoice.supplier_trn,
        supplier_name=invoice.supplier_name,
        supplier_address=invoice.supplier_address,
        supplier_peppol_id=invoice.supplier_peppol_id,
        customer_trn=invoice.customer_trn,
        customer_name=invoice.customer_name,
        customer_email=invoice.customer_email,
        customer_address=invoice.customer_address,
        customer_peppol_id=invoice.customer_peppol_id,
        subtotal_amount=invoice.subtotal_amount,
        tax_amount=invoice.tax_amount,
        total_amount=invoice.total_amount,
        amount_due=invoice.amount_due,
        xml_file_path=invoice.xml_file_path,
        pdf_file_path=invoice.pdf_file_path,
        share_token=invoice.share_token,
        created_at=invoice.created_at.isoformat(),
        sent_at=invoice.sent_at.isoformat() if invoice.sent_at else None,
        viewed_at=invoice.viewed_at.isoformat() if invoice.viewed_at else None,
        line_items=[
            InvoiceLineItemOut(
                id=li.id,
                line_number=li.line_number,
                item_name=li.item_name,
                item_description=li.item_description,
                quantity=li.quantity,
                unit_code=li.unit_code,
                unit_price=li.unit_price,
                line_extension_amount=li.line_extension_amount,
                tax_category=li.tax_category,
                tax_percent=li.tax_percent,
                tax_amount=li.tax_amount,
                line_total_amount=li.line_total_amount
            ) for li in invoice.line_items
        ],
        tax_breakdowns=[
            InvoiceTaxBreakdownOut(
                id=tb.id,
                tax_category=tb.tax_category,
                taxable_amount=tb.taxable_amount,
                tax_percent=tb.tax_percent,
                tax_amount=tb.tax_amount
            ) for tb in invoice.tax_breakdowns
        ]
    )
