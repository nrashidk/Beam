--
-- PostgreSQL database dump
--

\restrict nGCWSXXidDUidE8Ep9ALzh8Q8nSB1bioRMiufJ9d7Avd5eNM3GjZdantNcgeH20

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS '';


--
-- Name: audit_file_status_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.audit_file_status_t AS ENUM (
    'GENERATING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public.audit_file_status_t OWNER TO postgres;

--
-- Name: auditfilestatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.auditfilestatus AS ENUM (
    'GENERATING',
    'COMPLETED',
    'FAILED'
);


ALTER TYPE public.auditfilestatus OWNER TO postgres;

--
-- Name: company_status_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.company_status_t AS ENUM (
    'PENDING_REVIEW',
    'ACTIVE',
    'SUSPENDED',
    'REJECTED'
);


ALTER TYPE public.company_status_t OWNER TO postgres;

--
-- Name: companystatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.companystatus AS ENUM (
    'PENDING_REVIEW',
    'ACTIVE',
    'SUSPENDED',
    'REJECTED'
);


ALTER TYPE public.companystatus OWNER TO postgres;

--
-- Name: document_status_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.document_status_t AS ENUM (
    'PENDING_REVIEW',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public.document_status_t OWNER TO postgres;

--
-- Name: document_type_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.document_type_t AS ENUM (
    'BUSINESS_LICENSE',
    'TRN_CERTIFICATE',
    'TRADE_LICENSE',
    'PASSPORT',
    'EMIRATES_ID'
);


ALTER TYPE public.document_type_t OWNER TO postgres;

--
-- Name: documentstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.documentstatus AS ENUM (
    'PENDING_REVIEW',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public.documentstatus OWNER TO postgres;

--
-- Name: documenttype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.documenttype AS ENUM (
    'BUSINESS_LICENSE',
    'TRN_CERTIFICATE',
    'TRADE_LICENSE',
    'PASSPORT',
    'EMIRATES_ID'
);


ALTER TYPE public.documenttype OWNER TO postgres;

--
-- Name: goods_receipt_status_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.goods_receipt_status_t AS ENUM (
    'PENDING',
    'RECEIVED',
    'PARTIAL',
    'REJECTED'
);


ALTER TYPE public.goods_receipt_status_t OWNER TO postgres;

--
-- Name: goodsreceiptstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.goodsreceiptstatus AS ENUM (
    'PENDING',
    'RECEIVED',
    'PARTIAL',
    'REJECTED'
);


ALTER TYPE public.goodsreceiptstatus OWNER TO postgres;

--
-- Name: invoice_status_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.invoice_status_t AS ENUM (
    'DRAFT',
    'ISSUED',
    'SENT',
    'VIEWED',
    'PAID',
    'CANCELLED',
    'OVERDUE'
);


ALTER TYPE public.invoice_status_t OWNER TO postgres;

--
-- Name: invoice_type_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.invoice_type_t AS ENUM (
    '380',
    '381',
    '480',
    '81',
    '383'
);


ALTER TYPE public.invoice_type_t OWNER TO postgres;

--
-- Name: invoicestatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.invoicestatus AS ENUM (
    'DRAFT',
    'ISSUED',
    'SENT',
    'VIEWED',
    'PAID',
    'CANCELLED',
    'OVERDUE'
);


ALTER TYPE public.invoicestatus OWNER TO postgres;

--
-- Name: invoicetype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.invoicetype AS ENUM (
    'TAX_INVOICE',
    'TAX_CREDIT_NOTE',
    'COMMERCIAL_INVOICE',
    'CREDIT_NOTE_OUT_OF_SCOPE',
    'TAX_DEBIT_NOTE'
);


ALTER TYPE public.invoicetype OWNER TO postgres;

--
-- Name: inward_invoice_status_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.inward_invoice_status_t AS ENUM (
    'RECEIVED',
    'PENDING_REVIEW',
    'MATCHED',
    'APPROVED',
    'REJECTED',
    'PAID',
    'DISPUTED',
    'CANCELLED'
);


ALTER TYPE public.inward_invoice_status_t OWNER TO postgres;

--
-- Name: inwardinvoicestatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.inwardinvoicestatus AS ENUM (
    'RECEIVED',
    'PENDING_REVIEW',
    'MATCHED',
    'APPROVED',
    'REJECTED',
    'PAID',
    'DISPUTED',
    'CANCELLED'
);


ALTER TYPE public.inwardinvoicestatus OWNER TO postgres;

--
-- Name: matching_status_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.matching_status_t AS ENUM (
    'NOT_MATCHED',
    'PARTIAL_MATCH',
    'FULL_MATCH',
    'VARIANCE_DETECTED'
);


ALTER TYPE public.matching_status_t OWNER TO postgres;

--
-- Name: matchingstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.matchingstatus AS ENUM (
    'NOT_MATCHED',
    'PARTIAL_MATCH',
    'FULL_MATCH',
    'VARIANCE_DETECTED'
);


ALTER TYPE public.matchingstatus OWNER TO postgres;

--
-- Name: purchase_order_status_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.purchase_order_status_t AS ENUM (
    'DRAFT',
    'SENT',
    'ACKNOWLEDGED',
    'FULFILLED',
    'CANCELLED'
);


ALTER TYPE public.purchase_order_status_t OWNER TO postgres;

--
-- Name: purchaseorderstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.purchaseorderstatus AS ENUM (
    'DRAFT',
    'SENT',
    'ACKNOWLEDGED',
    'FULFILLED',
    'CANCELLED'
);


ALTER TYPE public.purchaseorderstatus OWNER TO postgres;

--
-- Name: role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.role AS ENUM (
    'SUPER_ADMIN',
    'COMPANY_ADMIN',
    'FINANCE_USER',
    'BUSINESS_ADMIN',
    'READ_ONLY'
);


ALTER TYPE public.role OWNER TO postgres;

--
-- Name: role_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.role_t AS ENUM (
    'SUPER_ADMIN',
    'COMPANY_ADMIN',
    'BUSINESS_ADMIN',
    'FINANCE_USER'
);


ALTER TYPE public.role_t OWNER TO postgres;

--
-- Name: subscription_status_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.subscription_status_t AS ENUM (
    'TRIAL',
    'ACTIVE',
    'PAST_DUE',
    'CANCELED'
);


ALTER TYPE public.subscription_status_t OWNER TO postgres;

--
-- Name: subscriptionstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.subscriptionstatus AS ENUM (
    'TRIAL',
    'ACTIVE',
    'PAST_DUE',
    'CANCELED'
);


ALTER TYPE public.subscriptionstatus OWNER TO postgres;

--
-- Name: tax_category_t; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tax_category_t AS ENUM (
    'S',
    'Z',
    'E',
    'O'
);


ALTER TYPE public.tax_category_t OWNER TO postgres;

--
-- Name: taxcategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.taxcategory AS ENUM (
    'STANDARD',
    'ZERO',
    'EXEMPT',
    'OUT_OF_SCOPE'
);


ALTER TYPE public.taxcategory OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    account_code character varying(20) NOT NULL,
    account_name character varying(100) NOT NULL,
    account_name_ar character varying(100),
    account_type character varying(20) NOT NULL,
    parent_account_id character varying,
    is_system boolean,
    is_active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: audit_files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_files (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    file_name character varying NOT NULL,
    file_path character varying NOT NULL,
    file_size integer,
    format character varying,
    period_start_date date NOT NULL,
    period_end_date date NOT NULL,
    status public.auditfilestatus,
    generated_by_user_id character varying NOT NULL,
    generated_at timestamp without time zone,
    total_invoices integer,
    total_customers integer,
    total_amount double precision,
    total_vat double precision,
    error_message text,
    created_at timestamp without time zone
);


ALTER TABLE public.audit_files OWNER TO postgres;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id character varying NOT NULL,
    entity_type character varying NOT NULL,
    entity_id character varying NOT NULL,
    action character varying NOT NULL,
    field_name character varying,
    old_value text,
    new_value text,
    changed_by_user_id character varying,
    changed_by_email character varying,
    ip_address character varying,
    user_agent text,
    "timestamp" timestamp without time zone NOT NULL,
    company_id character varying
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id character varying NOT NULL,
    company_id character varying,
    user_id character varying,
    action character varying NOT NULL,
    resource_type character varying,
    resource_id character varying,
    old_value text,
    new_value text,
    description text,
    ip_address character varying,
    user_agent character varying,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: backup_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backup_logs (
    id character varying NOT NULL,
    started_at timestamp without time zone NOT NULL,
    completed_at timestamp without time zone,
    filename character varying,
    file_size_bytes integer,
    checksum_sha256 character varying(64),
    storage_path character varying,
    status character varying(10) NOT NULL,
    error_message text,
    triggered_by character varying
);


ALTER TABLE public.backup_logs OWNER TO postgres;

--
-- Name: billing_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.billing_invoices (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    invoice_number character varying NOT NULL,
    billing_period_start date NOT NULL,
    billing_period_end date NOT NULL,
    subscription_fee double precision,
    peppol_usage_count integer,
    peppol_usage_fee double precision,
    total_amount double precision NOT NULL,
    status character varying,
    stripe_invoice_id character varying,
    paid_at timestamp without time zone,
    payment_method_id character varying,
    created_at timestamp without time zone,
    sent_at timestamp without time zone
);


ALTER TABLE public.billing_invoices OWNER TO postgres;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id character varying NOT NULL,
    legal_name character varying,
    country character varying,
    status public.companystatus,
    trn character varying,
    business_type character varying,
    business_activity character varying,
    registration_number character varying,
    registration_date date,
    email character varying,
    phone character varying,
    website character varying,
    address_line1 character varying,
    address_line2 character varying,
    city character varying,
    emirate character varying,
    po_box character varying,
    authorized_person_name character varying,
    authorized_person_title character varying,
    authorized_person_email character varying,
    authorized_person_phone character varying,
    email_verified boolean,
    verification_token character varying,
    verification_sent_at timestamp without time zone,
    created_at timestamp without time zone,
    password_hash character varying,
    password_reset_token character varying,
    password_reset_expires timestamp without time zone,
    free_plan_type character varying,
    free_plan_duration_months integer,
    free_plan_invoice_limit integer,
    free_plan_start_date timestamp without time zone,
    invoices_generated integer DEFAULT 0,
    subscription_plan_id character varying,
    mfa_enabled boolean DEFAULT false,
    mfa_method character varying(20),
    mfa_secret text,
    mfa_backup_codes text,
    mfa_enrolled_at timestamp without time zone,
    mfa_last_verified_at timestamp without time zone,
    trial_status character varying(20),
    trial_start_date timestamp without time zone,
    trial_invoice_count integer DEFAULT 0,
    trial_ended_at timestamp without time zone,
    stripe_customer_id character varying(255),
    peppol_enabled boolean DEFAULT false,
    peppol_provider character varying(50),
    peppol_participant_id character varying(255),
    peppol_base_url text,
    peppol_api_key text,
    peppol_configured_at timestamp without time zone,
    peppol_last_tested_at timestamp without time zone,
    vat_enabled boolean DEFAULT false,
    vat_registration_date date,
    approved_at timestamp without time zone,
    rejected_at timestamp without time zone,
    vat_certificate_path character varying
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: company_branding; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_branding (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    logo_file_name character varying,
    logo_file_path character varying,
    logo_file_size integer,
    logo_mime_type character varying,
    logo_uploaded_at timestamp without time zone,
    stamp_file_name character varying,
    stamp_file_path character varying,
    stamp_file_size integer,
    stamp_mime_type character varying,
    stamp_uploaded_at timestamp without time zone,
    primary_color character varying,
    secondary_color character varying,
    font_family character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.company_branding OWNER TO postgres;

--
-- Name: company_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_documents (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    document_type public.documenttype NOT NULL,
    file_name character varying NOT NULL,
    file_path character varying NOT NULL,
    file_size integer,
    mime_type character varying,
    status public.documentstatus,
    issue_date date,
    expiry_date date,
    document_number character varying,
    uploaded_at timestamp without time zone
);


ALTER TABLE public.company_documents OWNER TO postgres;

--
-- Name: company_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company_subscriptions (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    plan_id character varying NOT NULL,
    status public.subscriptionstatus,
    billing_cycle character varying,
    current_period_start date NOT NULL,
    current_period_end date NOT NULL,
    invoices_this_period integer,
    created_at timestamp without time zone
);


ALTER TABLE public.company_subscriptions OWNER TO postgres;

--
-- Name: content_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_blocks (
    id character varying NOT NULL,
    key character varying NOT NULL,
    value text NOT NULL,
    description character varying,
    section character varying,
    updated_at timestamp without time zone,
    updated_by character varying
);


ALTER TABLE public.content_blocks OWNER TO postgres;

--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.expense_categories (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    name character varying NOT NULL,
    description text,
    is_default boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.expense_categories OWNER TO postgres;

--
-- Name: expenses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.expenses (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    expense_date date NOT NULL,
    category character varying NOT NULL,
    description text,
    amount double precision NOT NULL,
    vat_amount double precision,
    total_amount double precision NOT NULL,
    currency_code character varying,
    reference_number character varying,
    supplier_name character varying,
    notes text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    tax_code character varying DEFAULT 'SR'::character varying,
    vendor_id character varying,
    created_by_user_id character varying
);


ALTER TABLE public.expenses OWNER TO postgres;

--
-- Name: featured_businesses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.featured_businesses (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    display_name character varying,
    logo_url character varying,
    is_active boolean,
    display_order integer,
    added_by_user_id character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.featured_businesses OWNER TO postgres;

--
-- Name: goods_receipt_line_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goods_receipt_line_items (
    id character varying NOT NULL,
    grn_id character varying NOT NULL,
    po_line_item_id character varying,
    line_number integer NOT NULL,
    item_name character varying NOT NULL,
    item_code character varying,
    quantity_received double precision NOT NULL,
    quantity_accepted double precision NOT NULL,
    quantity_rejected double precision,
    unit_code character varying,
    condition character varying,
    notes text,
    created_at timestamp without time zone
);


ALTER TABLE public.goods_receipt_line_items OWNER TO postgres;

--
-- Name: goods_receipts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goods_receipts (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    po_id character varying,
    grn_number character varying NOT NULL,
    status public.goodsreceiptstatus,
    receipt_date date NOT NULL,
    received_by_user_id character varying,
    supplier_trn character varying NOT NULL,
    supplier_name character varying NOT NULL,
    supplier_delivery_note character varying,
    total_items_received integer,
    total_value double precision,
    inspection_passed boolean,
    quality_notes text,
    damaged_items_count integer,
    notes text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.goods_receipts OWNER TO postgres;

--
-- Name: integrity_checks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integrity_checks (
    id character varying NOT NULL,
    company_id character varying,
    performed_by_user_id character varying,
    checked_at timestamp without time zone NOT NULL,
    total_invoices integer NOT NULL,
    valid_links integer NOT NULL,
    integrity_ok boolean NOT NULL,
    first_broken_invoice_id character varying,
    first_broken_invoice_number character varying,
    first_broken_invoice_date character varying
);


ALTER TABLE public.integrity_checks OWNER TO postgres;

--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_items (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    item_name character varying NOT NULL,
    item_code character varying,
    description text,
    unit character varying,
    current_stock double precision,
    min_stock_level double precision,
    unit_cost double precision,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.inventory_items OWNER TO postgres;

--
-- Name: inventory_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_transactions (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    inventory_item_id character varying NOT NULL,
    transaction_type character varying NOT NULL,
    quantity double precision NOT NULL,
    transaction_date date NOT NULL,
    reference_type character varying,
    reference_id character varying,
    notes text,
    stock_after double precision NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.inventory_transactions OWNER TO postgres;

--
-- Name: invoice_line_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_line_items (
    id character varying NOT NULL,
    invoice_id character varying NOT NULL,
    line_number integer NOT NULL,
    item_name character varying NOT NULL,
    item_description text,
    item_code character varying,
    quantity double precision NOT NULL,
    unit_code character varying,
    unit_price double precision NOT NULL,
    line_extension_amount double precision NOT NULL,
    tax_category public.taxcategory NOT NULL,
    tax_percent double precision,
    tax_amount double precision,
    line_total_amount double precision NOT NULL,
    created_at timestamp without time zone,
    tax_code character varying DEFAULT 'SR'::character varying
);


ALTER TABLE public.invoice_line_items OWNER TO postgres;

--
-- Name: invoice_tax_breakdowns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_tax_breakdowns (
    id character varying NOT NULL,
    invoice_id character varying NOT NULL,
    tax_category public.taxcategory NOT NULL,
    taxable_amount double precision NOT NULL,
    tax_percent double precision NOT NULL,
    tax_amount double precision NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.invoice_tax_breakdowns OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    invoice_number character varying NOT NULL,
    invoice_type public.invoicetype NOT NULL,
    status public.invoicestatus,
    issue_date date NOT NULL,
    due_date date,
    currency_code character varying,
    supplier_trn character varying,
    supplier_name character varying NOT NULL,
    supplier_address text,
    supplier_city character varying,
    supplier_country character varying,
    supplier_peppol_id character varying,
    customer_trn character varying,
    customer_name character varying NOT NULL,
    customer_email character varying,
    customer_address text,
    customer_city character varying,
    customer_country character varying,
    customer_peppol_id character varying,
    subtotal_amount double precision,
    tax_amount double precision,
    total_amount double precision,
    amount_due double precision,
    total_amount_aed double precision,
    payment_terms text,
    payment_due_days integer,
    invoice_notes text,
    reference_number character varying,
    preceding_invoice_id character varying,
    credit_note_reason character varying,
    xml_file_path character varying,
    pdf_file_path character varying,
    xml_hash character varying,
    share_token character varying,
    sent_at timestamp without time zone,
    viewed_at timestamp without time zone,
    paid_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    prev_invoice_hash character varying(64),
    signature_b64 text,
    signing_cert_serial character varying(50),
    signing_timestamp timestamp without time zone,
    peppol_message_id character varying(100),
    peppol_status character varying(20),
    peppol_provider character varying(50),
    peppol_sent_at timestamp without time zone,
    peppol_response text,
    tax_code character varying DEFAULT 'SR'::character varying,
    invoice_classification character varying DEFAULT 'standard'::character varying,
    created_by_user_id character varying,
    payment_verified_by_user_id character varying,
    payment_verified_at timestamp without time zone,
    payment_method character varying,
    debit_note_reason character varying,
    supply_date date,
    version integer DEFAULT 1 NOT NULL,
    is_archived boolean DEFAULT false NOT NULL,
    archived_at timestamp without time zone
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: inward_invoice_line_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inward_invoice_line_items (
    id character varying NOT NULL,
    inward_invoice_id character varying NOT NULL,
    line_number integer NOT NULL,
    item_name character varying NOT NULL,
    item_description text,
    item_code character varying,
    quantity double precision NOT NULL,
    unit_code character varying,
    unit_price double precision NOT NULL,
    line_extension_amount double precision NOT NULL,
    tax_category public.taxcategory NOT NULL,
    tax_percent double precision,
    tax_amount double precision,
    line_total_amount double precision NOT NULL,
    po_line_item_id character varying,
    grn_line_item_id character varying,
    match_status character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.inward_invoice_line_items OWNER TO postgres;

--
-- Name: inward_invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inward_invoices (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    supplier_invoice_number character varying NOT NULL,
    invoice_type public.invoicetype,
    status public.inwardinvoicestatus,
    invoice_date date NOT NULL,
    due_date date,
    received_at timestamp without time zone,
    supplier_trn character varying NOT NULL,
    supplier_name character varying NOT NULL,
    supplier_address text,
    supplier_peppol_id character varying,
    supplier_company_id character varying,
    customer_trn character varying NOT NULL,
    customer_name character varying NOT NULL,
    currency_code character varying,
    subtotal_amount double precision NOT NULL,
    tax_amount double precision NOT NULL,
    total_amount double precision NOT NULL,
    amount_due double precision NOT NULL,
    xml_file_path character varying,
    pdf_file_path character varying,
    xml_hash character varying,
    peppol_message_id character varying,
    peppol_sender_id character varying,
    peppol_provider character varying,
    peppol_received_at timestamp without time zone,
    po_id character varying,
    grn_id character varying,
    matching_status public.matchingstatus,
    po_match_score double precision,
    grn_match_score double precision,
    amount_variance double precision,
    quantity_variance double precision,
    reviewed_by_user_id character varying,
    reviewed_at timestamp without time zone,
    approved_by_user_id character varying,
    approved_at timestamp without time zone,
    rejection_reason text,
    payment_status character varying,
    payment_method character varying,
    paid_amount double precision,
    paid_at timestamp without time zone,
    payment_reference character varying,
    disputed_at timestamp without time zone,
    dispute_reason text,
    dispute_resolved_at timestamp without time zone,
    notes text,
    reference_number character varying,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    total_amount_aed double precision
);


ALTER TABLE public.inward_invoices OWNER TO postgres;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.journal_entries (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    entry_date date NOT NULL,
    reference_type character varying(50),
    reference_id character varying,
    reference_number character varying(100),
    description character varying(500),
    is_posted boolean,
    created_by_user_id character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.journal_entries OWNER TO postgres;

--
-- Name: journal_entry_lines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.journal_entry_lines (
    id character varying NOT NULL,
    journal_entry_id character varying NOT NULL,
    account_id character varying NOT NULL,
    account_code character varying(20),
    account_name character varying(100),
    debit_amount double precision,
    credit_amount double precision,
    currency character varying(3),
    amount_aed double precision,
    description character varying(500),
    line_number integer
);


ALTER TABLE public.journal_entry_lines OWNER TO postgres;

--
-- Name: password_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_history (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    password_hash character varying NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.password_history OWNER TO postgres;

--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_methods (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    stripe_payment_method_id character varying NOT NULL,
    card_brand character varying,
    card_last4 character varying,
    exp_month integer,
    exp_year integer,
    billing_email character varying,
    billing_name character varying,
    is_default boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.payment_methods OWNER TO postgres;

--
-- Name: peppol_usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.peppol_usage (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    invoice_id character varying,
    transmission_date timestamp without time zone,
    status character varying NOT NULL,
    fee_amount double precision,
    month_year character varying NOT NULL,
    billed boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.peppol_usage OWNER TO postgres;

--
-- Name: purchase_order_line_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_order_line_items (
    id character varying NOT NULL,
    po_id character varying NOT NULL,
    line_number integer NOT NULL,
    item_name character varying NOT NULL,
    item_description text,
    item_code character varying,
    quantity_ordered double precision NOT NULL,
    quantity_received double precision,
    unit_code character varying,
    unit_price double precision NOT NULL,
    line_total double precision NOT NULL,
    tax_category public.taxcategory,
    tax_percent double precision,
    created_at timestamp without time zone
);


ALTER TABLE public.purchase_order_line_items OWNER TO postgres;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_orders (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    po_number character varying NOT NULL,
    status public.purchaseorderstatus,
    supplier_trn character varying,
    supplier_name character varying NOT NULL,
    supplier_contact_email character varying,
    supplier_address text,
    supplier_peppol_id character varying,
    order_date date NOT NULL,
    expected_delivery_date date,
    delivery_address text,
    currency_code character varying,
    expected_subtotal double precision,
    expected_tax double precision,
    expected_total double precision NOT NULL,
    received_invoice_count integer,
    matched_invoice_count integer,
    received_amount_total double precision,
    variance_amount double precision,
    reference_number character varying,
    notes text,
    approved_by_user_id character varying,
    approved_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.purchase_orders OWNER TO postgres;

--
-- Name: registration_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registration_progress (
    id character varying NOT NULL,
    company_id character varying,
    current_step integer,
    step_company_info boolean,
    step_business_details boolean,
    step_documents boolean,
    step_plan_selection boolean,
    step_review boolean,
    completed boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.registration_progress OWNER TO postgres;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscription_plans (
    id character varying NOT NULL,
    name character varying NOT NULL,
    description text,
    price_monthly double precision,
    price_yearly double precision,
    max_invoices_per_month integer,
    max_users integer,
    max_pos_devices integer,
    allow_api_access boolean,
    allow_branding boolean,
    allow_multi_currency boolean,
    priority_support boolean,
    active boolean,
    created_at timestamp without time zone,
    max_business_admins integer DEFAULT 0,
    max_finance_users integer DEFAULT 1
);


ALTER TABLE public.subscription_plans OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    tier character varying NOT NULL,
    billing_cycle_months integer,
    monthly_price double precision,
    discount_percent double precision,
    status character varying,
    stripe_subscription_id character varying,
    stripe_customer_id character varying,
    current_period_start timestamp without time zone NOT NULL,
    current_period_end timestamp without time zone NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    cancelled_at timestamp without time zone
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying NOT NULL,
    email character varying NOT NULL,
    password_hash character varying,
    role public.role NOT NULL,
    company_id character varying,
    is_owner boolean DEFAULT false,
    full_name character varying,
    invited_by character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp without time zone,
    mfa_enabled boolean DEFAULT false,
    mfa_method character varying(20),
    mfa_secret text,
    mfa_backup_codes text,
    mfa_enrolled_at timestamp without time zone,
    mfa_last_verified_at timestamp without time zone,
    must_change_password boolean DEFAULT false,
    password_changed_at timestamp without time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone,
    failed_login_count integer DEFAULT 0
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: vat_returns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vat_returns (
    id character varying NOT NULL,
    company_id character varying NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    total_sales_invoices integer,
    total_purchase_invoices integer,
    standard_rated_sales double precision,
    tax_refunds_provided double precision,
    output_vat double precision,
    standard_rated_purchases double precision,
    purchase_expenses double precision,
    input_vat_bills double precision,
    input_vat_expenses double precision,
    total_input_vat double precision,
    net_vat_payable double precision,
    generated_by_user_id character varying NOT NULL,
    created_at timestamp without time zone,
    zero_rated_sales double precision DEFAULT 0.0,
    exempt_sales double precision DEFAULT 0.0,
    out_of_scope_sales double precision DEFAULT 0.0,
    total_sales double precision DEFAULT 0.0,
    zero_rated_purchases double precision DEFAULT 0.0,
    exempt_purchases double precision DEFAULT 0.0,
    reverse_charge_sales double precision DEFAULT 0.0,
    reverse_charge_vat double precision DEFAULT 0.0
);


ALTER TABLE public.vat_returns OWNER TO postgres;

--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, company_id, account_code, account_name, account_name_ar, account_type, parent_account_id, is_system, is_active, created_at) FROM stdin;
503c0c44-37ea-48e3-bc9a-6bfcde1e6288	co_f73de616	1000	Cash / Bank	نقد / بنك	ASSET	\N	t	t	2026-03-27 21:46:44.279974
60862f3d-3075-43ea-97e7-73c93444aa14	co_f73de616	1100	Accounts Receivable	حسابات القبض	ASSET	\N	t	t	2026-03-27 21:46:44.279977
60e847f8-c813-40b9-a2a3-7d914b2588ce	co_f73de616	1200	VAT Receivable	ضريبة القيمة المضافة المستردة	ASSET	\N	t	t	2026-03-27 21:46:44.279978
d44087c4-661c-4d30-820f-7cdf8a484e33	co_f73de616	2100	Accounts Payable	حسابات الدفع	LIABILITY	\N	t	t	2026-03-27 21:46:44.279978
0ef2f93f-f994-4a16-9d17-7d51822dce1d	co_f73de616	2200	VAT Payable	ضريبة القيمة المضافة المستحقة	LIABILITY	\N	t	t	2026-03-27 21:46:44.27998
af053143-7e6e-4eae-bd95-786dc5b8e2c6	co_f73de616	3000	Sales Revenue	إيرادات المبيعات	REVENUE	\N	t	t	2026-03-27 21:46:44.27998
c35f0652-b121-4e20-b99d-1d7c6c268235	co_f73de616	4000	Purchase / Cost of Goods	المشتريات / تكلفة البضاعة	EXPENSE	\N	t	t	2026-03-27 21:46:44.279981
\.


--
-- Data for Name: audit_files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_files (id, company_id, file_name, file_path, file_size, format, period_start_date, period_end_date, status, generated_by_user_id, generated_at, total_invoices, total_customers, total_amount, total_vat, error_message, created_at) FROM stdin;
faf_67798660483a	co_f73de616	FTA_FAF_100123456700003_2025-01-01_to_2025-12-31.zip	/home/runner/workspace/artifacts/audit_files/co_f73de616/FTA_FAF_100123456700003_2025-01-01_to_2025-12-31.zip	957	ZIP	2025-01-01	2025-12-31	COMPLETED	user_8ed5d4b2	2026-03-28 11:38:44.17393	0	0	0	0	\N	2026-03-28 11:38:44.173933
faf_a1af0c96699d	co_f73de616	FTA_FAF_100123456700003_2026-01-01_to_2026-03-28.zip	/home/runner/workspace/artifacts/audit_files/co_f73de616/FTA_FAF_100123456700003_2026-01-01_to_2026-03-28.zip	952	ZIP	2026-01-01	2026-03-28	COMPLETED	user_8ed5d4b2	2026-03-28 11:40:05.46236	0	0	0	0	\N	2026-03-28 11:40:05.462362
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, entity_type, entity_id, action, field_name, old_value, new_value, changed_by_user_id, changed_by_email, ip_address, user_agent, "timestamp", company_id) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, company_id, user_id, action, resource_type, resource_id, old_value, new_value, description, ip_address, user_agent, created_at) FROM stdin;
al_2f448bceb7734163	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 21:32:19.407912
al_78a013461c69476e	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 21:32:27.63672
al_4d412f1f3e5d4e7f	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 21:33:11.675632
al_91867d6c6bf34781	co_f73de616	user_8ed5d4b2	VAT_RETURN_GENERATED	vat_return	vr_7dac9a8404e9	\N	\N	VAT return generated for period 2024-01-01 to 2025-03-31	\N	\N	2026-03-27 21:33:11.753495
al_7f0e32024a1c41d0	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 21:34:20.58171
al_8a181a0739fa4501	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 21:37:32.343705
al_19af9856f39a4555	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 21:41:33.780269
al_ecacc35b9e734301	co_f73de616	user_8ed5d4b2	VAT_RETURN_GENERATED	vat_return	vr_fd5c3938b48c	\N	\N	VAT return generated for period 2026-03-01 to 2026-03-27	\N	\N	2026-03-27 21:42:26.754829
al_25f9d51ea90f43e7	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 21:46:36.473326
al_0e0fe742262f496d	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 21:50:10.527154
al_c457a8ee52bb4400	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 21:56:35.02358
al_672a5b7532f1493f	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 21:57:43.475406
al_11e5ae2cff5b4e33	co_f73de616	user_8ed5d4b2	VAT_RETURN_GENERATED	vat_return	vr_00b58c656680	\N	\N	VAT return generated for period 2026-03-01 to 2026-03-27	\N	\N	2026-03-27 21:58:33.376328
al_207157b985364f14	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:12:07.957283
al_5a44af89bd6743f2	co_f73de616	user_8ed5d4b2	VAT_RETURN_GENERATED	vat_return	vr_e5f23c1fc8b3	\N	\N	VAT return generated for period 2024-01-01 to 2025-03-31	\N	\N	2026-03-27 22:12:08.05599
al_0b613ec692c24817	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:13:08.020809
al_5dfd2861d17a4c22	co_f73de616	user_8ed5d4b2	VAT_RETURN_GENERATED	vat_return	vr_05f15670026a	\N	\N	VAT return generated for period 2026-03-01 to 2026-03-27	\N	\N	2026-03-27 22:13:24.006867
al_bdc43b59471746e8	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:17:23.4821
al_27b504cf2fbc4c6c	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:17:35.118189
al_86d4cf1c8c384d8f	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:18:32.378691
al_fb99d3c06f9e41e6	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:18:52.402478
al_17784ade4bea4d47	co_f73de616	user_8ed5d4b2	VAT_RETURN_GENERATED	vat_return	vr_9e26b1272b91	\N	\N	VAT return generated for period 2024-01-01 to 2024-12-31	\N	\N	2026-03-27 22:18:52.773979
al_43b79ed51ae14d3a	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:19:10.974832
al_71ca9c7ba2bc4cc3	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:19:19.919893
al_04b7fdcb240d4572	co_f73de616	user_8ed5d4b2	VAT_RETURN_GENERATED	vat_return	vr_27ad1b47c26a	\N	\N	VAT return generated for period 2024-01-01 to 2024-12-31	\N	\N	2026-03-27 22:19:19.973661
al_f438f0dabea54b2f	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:20:11.594185
al_a65bbedea6bf4160	co_f73de616	user_8ed5d4b2	VAT_RETURN_GENERATED	vat_return	vr_29219d079cb6	\N	\N	VAT return generated for period 2026-03-01 to 2026-03-27	\N	\N	2026-03-27 22:20:28.875929
al_fa67dfff79864e6c	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:28:13.975989
al_d13b67a178ff42d8	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:29:36.888672
al_ed398e0b856a4188	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:31:49.62494
al_07868645dd5e4d87	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:36:16.351523
al_4271d296081c4f67	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:38:07.931577
al_b85a851ddae64088	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:39:17.999784
al_de288e1e83274632	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:42:27.905732
al_28fe248668624fca	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:42:36.490255
al_a187edb9fed24952	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:44:30.045078
al_e5cb615f608f44ed	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:49:16.652905
al_f28f50d4e4924bff	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:52:26.254677
al_543173d2837444cc	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-27 22:55:25.490531
al_d1f9afac96344819	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:31:48.729984
al_c383da6b3a0642a7	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:31:56.972428
al_859f736a84bd4c4e	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:33:12.138977
al_0bcff3a21cd2425d	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:38:44.107363
al_6db5e27a3da0442a	co_f73de616	user_8ed5d4b2	FAF_GENERATED	audit_file	faf_67798660483a	\N	\N	FAF generated for period 2025-01-01 to 2025-12-31	\N	\N	2026-03-28 11:38:44.209211
al_aa3d50951ebc475c	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:38:55.216726
al_e7c91bdd8c6b481c	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:39:48.306141
al_2cd888d359444ffe	co_f73de616	user_8ed5d4b2	FAF_GENERATED	audit_file	faf_a1af0c96699d	\N	\N	FAF generated for period 2026-01-01 to 2026-03-28	\N	\N	2026-03-28 11:40:05.654398
al_057e0eb5a16b4d81	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:45:39.697968
al_46099a2364444fc7	co_f73de616	usr_29fc7fbf8944	USER_LOGIN	user	usr_29fc7fbf8944	\N	\N	User forcechgtest@involinks.test logged in	\N	\N	2026-03-28 11:45:48.015851
al_f69f770952fe4eec	co_f73de616	usr_29fc7fbf8944	USER_LOGIN	user	usr_29fc7fbf8944	\N	\N	User forcechgtest@involinks.test logged in	\N	\N	2026-03-28 11:46:00.786282
al_0522643ffe05448c	co_f73de616	usr_29fc7fbf8944	FORCED_PASSWORD_CHANGED	user	usr_29fc7fbf8944	\N	\N	User forcechgtest@involinks.test completed mandatory password change on first login	\N	\N	2026-03-28 11:46:01.365945
al_2e6832da868b4324	co_f73de616	usr_29fc7fbf8944	USER_LOGIN	user	usr_29fc7fbf8944	\N	\N	User forcechgtest@involinks.test logged in	\N	\N	2026-03-28 11:46:01.670152
al_ebfc8aa611c94466	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:46:09.926218
al_095f5b5843a443a7	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:47:02.873541
al_c53fd9a7ee464a66	co_f73de616	usr_29fc7fbf8944	USER_LOGIN	user	usr_29fc7fbf8944	\N	\N	User forcechgtest@involinks.test logged in	\N	\N	2026-03-28 11:47:24.124608
al_23ef341a237e475f	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:48:24.956169
al_667beace5db148c2	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:48:31.889081
al_1d2bccdf017f40da	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:48:38.947134
al_91c3e0bedcaf4114	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:54:36.26766
al_4033b211033d4faa	co_f73de616	usr_13ce12ffa251	USER_LOGIN	user	usr_13ce12ffa251	\N	\N	User forced2@involinks.test logged in	\N	\N	2026-03-28 11:54:37.126515
al_d19de58ca4874657	co_f73de616	usr_13ce12ffa251	FORCED_PASSWORD_CHANGED	user	usr_13ce12ffa251	\N	\N	User forced2@involinks.test completed mandatory password change on first login	\N	\N	2026-03-28 11:54:37.948367
al_d261467219e543e7	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:54:49.93561
al_66512e8c3e184ade	co_f73de616	user_8ed5d4b2	PASSWORD_CHANGED	user	usr_13ce12ffa251	\N	\N	Admin vattest@involinks.test reset password for forced2@involinks.test — forced change on next login	\N	\N	2026-03-28 11:54:50.392817
al_fe10ce89e9184f47	co_f73de616	usr_13ce12ffa251	USER_LOGIN	user	usr_13ce12ffa251	\N	\N	User forced2@involinks.test logged in	\N	\N	2026-03-28 11:54:51.138699
al_d8d44d0b4df748bd	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 11:58:00.485659
al_0001dac5e4c645db	co_f73de616	usr_dcbb97f8307f	USER_LOGIN	user	usr_dcbb97f8307f	\N	\N	User jwttest@involinks.test logged in	\N	\N	2026-03-28 11:58:01.220242
al_95830351bb184656	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:04:37.835422
al_7fd76b34dda04011	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:04:45.667893
al_98df119d2b084bd4	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:04:53.937078
al_839dc56c12934926	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:06:18.464815
al_54a9b1b7770b4515	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:10:54.807076
al_d60b50f3a02e4ab5	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:14:01.586169
al_9baeaa420b1a4580	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:18:21.981154
al_3ce88062fe9e4ad4	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:25:12.03016
al_f4359f58a58b4743	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:25:20.923007
al_29207a049e944b20	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:25:29.866253
al_61c1944311cf4dbe	co_f73de616	user_8ed5d4b2	PASSWORD_CHANGED	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test changed their password	\N	\N	2026-03-28 12:25:30.448611
al_9071329b1f244202	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:25:37.405554
al_8f9eb83f9b244cc4	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:26:02.418292
al_371cc8d113a3448a	co_f73de616	user_8ed5d4b2	PASSWORD_CHANGED	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test changed their password	\N	\N	2026-03-28 12:26:03.253023
al_8ec1dc1233694f12	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:30:07.638937
al_e13939dbee89469a	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:34:30.9957
al_41ba91a41bd24d9e	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:38:29.028824
al_cd9c96b1678d4a45	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:41:04.951075
al_0aadaff389a445c6	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:41:14.362501
al_1a7755c3826e4e30	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:41:23.681848
al_475754e4d11a451c	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:43:09.215914
al_a2c39fbbcc104791	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 12:51:28.647667
al_d28e5f5d992c41ec	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 12:51:38.304958
al_3300a233a58f4b3f	\N	user_60763c2b	BACKUP_VERIFIED	system	backup	\N	\N	Backup recoverability manually verified by namitsuper@yopmail.com. Provider: Neon PostgreSQL PITR | RPO target: 24h	127.0.0.1	\N	2026-03-28 12:51:38.409739
al_425716ed536445b2	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 12:51:38.829856
al_b553071db38b46c3	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 12:54:37.898385
al_f1b74589ef7245d0	\N	user_60763c2b	BACKUP_VERIFIED	system	backup	\N	\N	Backup recoverability manually verified by namitsuper@yopmail.com. Provider: Neon PostgreSQL PITR | RPO target: 24h	127.0.0.1	\N	2026-03-28 12:54:38.067794
al_64859bd7cccd4ff4	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:00:49.517972
al_01670d99f1b34ce7	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 13:00:49.948496
al_5c070d92be3b4afc	co_f73de616	usr_29fc7fbf8944	USER_LOGIN	user	usr_29fc7fbf8944	\N	\N	User forcechgtest@involinks.test logged in	\N	\N	2026-03-28 13:01:32.549895
al_682c513138434513	co_f73de616	usr_29fc7fbf8944	USER_LOGIN	user	usr_29fc7fbf8944	\N	\N	User forcechgtest@involinks.test logged in	\N	\N	2026-03-28 13:01:32.881782
al_2a4adf30714b446b	co_f73de616	usr_29fc7fbf8944	USER_LOGIN	user	usr_29fc7fbf8944	\N	\N	User forcechgtest@involinks.test logged in	\N	\N	2026-03-28 13:08:49.229758
al_e7927943f3a145b8	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:08:49.680801
al_b9ddf139e0234f2e	co_f73de616	readonly-test-001	USER_LOGIN	user	readonly-test-001	\N	\N	User readonlytest@involinks.test logged in	\N	\N	2026-03-28 13:10:12.514139
al_bee61d11aa9748e6	co_f73de616	readonly-test-001	USER_LOGIN	user	readonly-test-001	\N	\N	User readonlytest@involinks.test logged in	\N	\N	2026-03-28 13:11:31.893899
al_20f29adb418e46fc	co_f73de616	usr_29fc7fbf8944	USER_LOGIN	user	usr_29fc7fbf8944	\N	\N	User forcechgtest@involinks.test logged in	\N	\N	2026-03-28 13:11:32.238758
al_18ab859df9584244	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:11:32.56815
al_ff5a7866366f42cd	co_f73de616	readonly-test-001	USER_LOGIN	user	readonly-test-001	\N	\N	User readonlytest@involinks.test logged in	\N	\N	2026-03-28 13:17:21.679521
al_f32fd797aa8b40cd	co_f73de616	usr_29fc7fbf8944	USER_LOGIN	user	usr_29fc7fbf8944	\N	\N	User forcechgtest@involinks.test logged in	\N	\N	2026-03-28 13:17:22.006397
al_c7357aef265c45cb	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:17:22.32284
al_39fdfae8e50346da	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:21:54.791111
al_5f6ad68439204f75	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:21:55.141132
al_e97bc2cb56a945e7	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:30:42.663671
al_73757510b1234c6a	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:33:42.357586
al_cfd11edd40c24444	\N	user_60763c2b	INTEGRITY_CHECK_FAILED	system	ic_020bc574e0fa4d84	\N	\N	Hash chain integrity check by namitsuper@yopmail.com. Total invoices checked: 15. Valid links: 0. First broken link: invoice INV-202510-0003 (ID=inv_4229479d9cee, date=2025-10-27).	10.84.3.13	\N	2026-03-28 13:34:06.795427
al_9dda80b7543a46ba	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:38:16.971824
al_94817368191249b4	\N	user_60763c2b	INTEGRITY_CHECK_FAILED	system	ic_250077b00f2040bb	\N	\N	Hash chain integrity check by namitsuper@yopmail.com. Total invoices checked: 15. Valid links: 3. First broken link: invoice INV-202510-0005 (ID=inv_887e97dea8e0, date=2025-10-27).	10.84.5.15	\N	2026-03-28 13:38:44.481884
al_6781389ced1a449d	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:43:31.705858
al_3270bf35bdf242bd	\N	user_60763c2b	INTEGRITY_CHECK_FAILED	system	ic_27671e0e02b348f6	\N	\N	Hash chain integrity check by namitsuper@yopmail.com. Total invoices checked: 15. Valid links: 0. First broken link: invoice INV-202510-0002 (ID=inv_da20971fd45b, date=2025-10-27).	10.84.0.13	\N	2026-03-28 13:43:51.239612
al_2876cc8802d8406f	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:48:00.196121
al_d36c0c2932ee4377	\N	user_60763c2b	INTEGRITY_CHECK_FAILED	system	ic_7e61afaed3814e1a	\N	\N	Hash chain integrity check by namitsuper@yopmail.com. Total invoices checked: 15. Valid links: 3. First broken link: invoice INV-202510-0002 (ID=inv_da20971fd45b, date=2025-10-27).	10.84.5.15	\N	2026-03-28 13:48:18.34139
al_7600bfda09af4f0d	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:52:21.234573
al_e1418504c30b4bc8	\N	user_60763c2b	INTEGRITY_CHECK_FAILED	system	ic_52755d15964b4103	\N	\N	Hash chain integrity check by namitsuper@yopmail.com. Total invoices checked: 9. Valid links: 3. First broken link: invoice INV-202510-0005 (ID=inv_887e97dea8e0, date=2025-10-27).	10.84.6.12	\N	2026-03-28 13:52:39.802276
al_86e0abaa0f65424c	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:55:12.637962
al_be79da24cc0f4eb8	\N	user_60763c2b	INTEGRITY_CHECK_FAILED	system	ic_5b9bb91da1974f0e	\N	\N	Hash chain integrity check by namitsuper@yopmail.com. Total invoices checked: 5. Valid links: 1. First broken link: invoice INV-202510-0008 (ID=inv_dc120af00337, date=2025-10-29).	127.0.0.1	\N	2026-03-28 13:55:12.745199
al_d5a2511b98404186	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 13:58:27.120806
al_30b342d434944fe8	\N	user_60763c2b	INTEGRITY_CHECK_FAILED	system	ic_fc1cda29cb20496a	\N	\N	Hash chain integrity check by namitsuper@yopmail.com. Total invoices checked: 15. Valid links: 3. First broken link: invoice INV-202510-0002 (ID=inv_da20971fd45b, date=2025-10-27).	127.0.0.1	\N	2026-03-28 13:58:27.197677
al_5a69494529d7488d	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 14:01:16.340789
al_c0b354eac8b74aa7	\N	user_60763c2b	INTEGRITY_CHECK_FAILED	system	ic_48b4b4276e544b09	\N	\N	Hash chain integrity check by namitsuper@yopmail.com. Total invoices checked: 9. Valid links: 3. First broken link: invoice INV-202510-0005 (ID=inv_887e97dea8e0, date=2025-10-27).	127.0.0.1	\N	2026-03-28 14:01:16.410145
al_6e76ab07b4784e44	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 14:04:15.033476
al_8e3fce8a71954c84	\N	user_60763c2b	INTEGRITY_CHECK_FAILED	system	ic_a497b2ac84164118	\N	\N	Hash chain integrity check by namitsuper@yopmail.com. Total invoices checked: 9. Valid links: 3. First broken link: invoice INV-202510-0005 (ID=inv_887e97dea8e0, date=2025-10-27).	127.0.0.1	\N	2026-03-28 14:04:15.102757
al_52bd40f589b549ce	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 14:08:06.209654
al_4f6db2f349084aa1	\N	user_60763c2b	INTEGRITY_CHECK_FAILED	system	ic_df681f4747414d2f	\N	\N	Hash chain integrity check by namitsuper@yopmail.com. Total invoices checked: 9. Valid links: 3. First broken link: invoice INV-202510-0005 (ID=inv_887e97dea8e0, date=2025-10-27).	127.0.0.1	\N	2026-03-28 14:08:06.44955
al_1a42667e75704e9b	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:18:43.262483
al_31aa774faba34417	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:21:01.92415
al_d781c37f6cbf4229	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:21:15.370829
al_247820043f4f4ef3	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:24:51.204455
al_4f6b67b4ae1344aa	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:28:20.922058
al_55b0d6da39d646a7	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:30:51.513316
al_69c0293a855e4109	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:31:28.439572
al_13c3156359bd4d6f	co_f73de616	user_8ed5d4b2	INVOICE_UPDATED	invoice	inv_d1441d4f812f	{"status": "DRAFT", "customer_name": "Test PUT Co", "total_amount": 100.0}	{"status": "DRAFT", "customer_name": "Test PUT Co", "total_amount": 157.5}	Invoice TI-00005 updated	\N	\N	2026-03-28 19:31:28.800405
al_72b036df328f4a0a	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:32:44.953266
al_b21cc8c0f99442b5	co_f73de616	user_8ed5d4b2	INVOICE_UPDATED	invoice	inv_f8a538c1bd0d	{"status": "DRAFT", "customer_name": "Test PUT Co", "total_amount": 100.0}	{"status": "DRAFT", "customer_name": "Test PUT Co", "total_amount": 420.0}	Invoice TI-00006 updated	\N	\N	2026-03-28 19:32:45.381762
al_d30c875b255a4ef1	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:36:46.931872
al_23d41acec3364927	co_f73de616	user_8ed5d4b2	INVOICE_UPDATED	invoice	inv_42a5aa5c8086	{"status": "DRAFT", "customer_name": "Local", "total_amount": 100.0}	{"status": "DRAFT", "customer_name": "EU Corp", "total_amount": 105.0}	Invoice TI-00008 updated	\N	\N	2026-03-28 19:36:47.435887
al_622102487d48417a	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:41:18.710015
al_92cffd9584b54e06	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:51:05.982378
al_6929aa31742f4dda	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:52:01.214927
al_1aab2197dcb5410f	co_f73de616	user_8ed5d4b2	JOURNAL_ENTRY_EDIT_BLOCKED	journal_entry	fake123	\N	\N	Attempt to edit journal entry fake123 blocked (FTA compliance — posted entries are immutable)	127.0.0.1	\N	2026-03-28 19:52:01.945647
al_91bd252cfa54423b	co_f73de616	user_8ed5d4b2	JOURNAL_ENTRY_DELETE_BLOCKED	journal_entry	fake123	\N	\N	Attempt to delete journal entry fake123 blocked (FTA compliance — posted entries are immutable)	127.0.0.1	\N	2026-03-28 19:52:01.993421
al_aceabf2578e14b15	co_f73de616	user_8ed5d4b2	USER_LOGIN	user	user_8ed5d4b2	\N	\N	User vattest@involinks.test logged in	\N	\N	2026-03-28 19:54:31.476363
al_225bb844f1d24790	\N	user_60763c2b	USER_LOGIN	user	user_60763c2b	\N	\N	User namitsuper@yopmail.com logged in	\N	\N	2026-03-28 20:04:15.390075
\.


--
-- Data for Name: backup_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backup_logs (id, started_at, completed_at, filename, file_size_bytes, checksum_sha256, storage_path, status, error_message, triggered_by) FROM stdin;
\.


--
-- Data for Name: billing_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.billing_invoices (id, company_id, invoice_number, billing_period_start, billing_period_end, subscription_fee, peppol_usage_count, peppol_usage_fee, total_amount, status, stripe_invoice_id, paid_at, payment_method_id, created_at, sent_at) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, legal_name, country, status, trn, business_type, business_activity, registration_number, registration_date, email, phone, website, address_line1, address_line2, city, emirate, po_box, authorized_person_name, authorized_person_title, authorized_person_email, authorized_person_phone, email_verified, verification_token, verification_sent_at, created_at, password_hash, password_reset_token, password_reset_expires, free_plan_type, free_plan_duration_months, free_plan_invoice_limit, free_plan_start_date, invoices_generated, subscription_plan_id, mfa_enabled, mfa_method, mfa_secret, mfa_backup_codes, mfa_enrolled_at, mfa_last_verified_at, trial_status, trial_start_date, trial_invoice_count, trial_ended_at, stripe_customer_id, peppol_enabled, peppol_provider, peppol_participant_id, peppol_base_url, peppol_api_key, peppol_configured_at, peppol_last_tested_at, vat_enabled, vat_registration_date, approved_at, rejected_at, vat_certificate_path) FROM stdin;
co_142451f3	\N	AE	ACTIVE	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-24 18:23:06.005192	\N	\N	\N	DURATION	3	\N	2025-10-26 19:08:46.184479	0	plan_free	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_5a372f9d	\N	AE	REJECTED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Dubai	\N	\N	\N	\N	\N	f	\N	\N	2025-10-24 18:59:21.004572	\N	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_2312b3d8	\N	AE	ACTIVE	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-24 20:47:16.946871	\N	\N	\N	DURATION	1	\N	2025-10-26 19:09:13.215388	0	plan_free	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_333cf1dd	Acme Corporation	AE	ACTIVE	\N	LLC	\N	\N	\N	john@acme.com	\N	\N	\N	\N	\N	Dubai	\N	\N	\N	\N	\N	t	\N	2025-10-24 18:08:37.312597	2025-10-24 18:08:20.499483	\N	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_158975c0	AutoTest Company 1761592143	AE	ACTIVE	\N	Technology	\N	\N	\N	autotest1761592143@test.com	+971501234567	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-27 19:09:05.009965	$2b$12$Rd3Hu0QXn8B2wZwqUt3m5enI2DnM33k5He7eF7UnuqI.5C7ErkJv6	\N	\N	INVOICE_COUNT	\N	100	2025-10-27 19:09:38.00563	0	plan_free	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_ef916725	Retro	AE	REJECTED	\N	Hair	\N	\N	\N	uae.n.me@gmail.com	0503000223	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-26 17:50:25.03951	$2b$12$wPWdZG3j6GcQOQ3g2q1m3.8JyYmSALryK0.cghl9nnL875GUu0bNG	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_548156b4	Net	AE	REJECTED	\N	Net	\N	\N	\N	net@net.com	0501231230	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-26 06:30:28.210862	$2b$12$MdfWO7xR2KvYUo11bf2cc.kWJEHf18aqUvWH/w.bwUizQysfsV0Ly	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_580c550f	Test2	AE	ACTIVE	\N	Hair2	\N	\N	\N	test2@gmail.com	0503000223	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-25 11:27:30.686463	$2b$12$Q3XVAtau/Z4tAKsXZvRJeOUZl5bskQuTqrl/KpuoYLtO109yHkONu	\N	\N	INVOICE_COUNT	\N	10	2025-10-30 03:57:25.801033	0	plan_free	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_7b711239	Test Company Ltd	AE	REJECTED	\N	Technology	\N	\N	\N	test@example.com	+971501234567	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-24 22:04:51.147882	$2b$12$21sO6qVUAn3M6D5zSu.XSO5KRFQ7lExfWYx3ErWZhwM68Dd5RTY0W	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_0afc5ba3	Nas	AE	REJECTED	\N	nas	\N	\N	\N	test@n.com	0402124000	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-26 10:58:23.823166	$2b$12$RBZ7AVfMm38pDPDJstzcy.fSMhBX4P1dllxycMF5X.JIRS7Smllxu	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_ef6032c1	Test Company LLC	AE	ACTIVE	\N		\N	\N	\N	newcompany@test.com		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-28 06:26:49.495117	$2b$12$AAGVhXh4vH8HbNbckTjMuuyiD/DCx4nFH4iFe/Rra/EDMVLEdOyBi	\N	\N	INVOICE_COUNT	\N	100	2025-10-28 06:28:09.294909	0	plan_free	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_862e31fc	Demo Trading LLC	AE	ACTIVE	\N	LLC	\N	\N	\N	admin@demotrading.ae	\N	\N	\N	\N	\N	Dubai	\N	\N	\N	\N	\N	t	\N	2025-10-24 18:23:30.554922	2025-10-24 18:23:26.114059	\N	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_7e575f3d	Test Company LLC	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	test@company.com	0501234567	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-28 08:05:16.303896	$2b$12$SZJfFuBr0zXRIkwPwzo2n.AcJaPYK10kXagCE3LUqPbDeDvTksDuO	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_40b90d3a	\N	AE	ACTIVE	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-24 20:47:04.712271	\N	\N	\N	INVOICE_COUNT	\N	1	2025-10-30 03:58:01.624249	0	plan_free	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_148bde71	Demo Business LLC	AE	REJECTED	\N	Retail	\N	\N	\N	demo@business.com	+971501111222	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-24 22:05:11.153671	$2b$12$.AA7JHLHDstpEvohhGCUT.Y9AGzsIBg99Q6cs5Rgq/C9AIJZjWj5W	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_ecdeb90e	test	AE	REJECTED	\N	test	\N	\N	\N	test@test.com	0503000223	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-24 22:06:06.442202	$2b$12$b1IyvW3GyRQMgfVEr2wLx.0lWInHmY06vvX/yQdyG90i3ILIDIn6i	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_5906d43b	Test Company	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	namit.company@yopmail.com	9874563210	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_d426d117c58943fda6f9cdbf94e7140b	2025-11-19 05:01:15.254349	2025-11-19 05:01:13.611943	$2b$12$D7Dl9pRbAn7QelUi8qf3FuEwAAm5RR3Pnm/eAiWu2IOTG75HskppG	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_1e52b1c3	\N	AE	REJECTED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-24 20:00:42.14412	\N	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_ae587f9d	Demo Company LLC	AE	ACTIVE	\N	LLC	\N	\N	\N	demo@company.com	\N	\N	\N	\N	\N	Dubai	\N	\N	\N	\N	\N	t	\N	2025-10-24 19:00:51.117168	2025-10-24 19:00:46.263312	$2b$12$FUiSceB3cmwqNQym11KoUe6zREZzJTsIqW7nzRjr9ll7yfP64qsp6	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_1800c65a	\N	AE	REJECTED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-24 18:06:09.600741	\N	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_a0c89b23	Thursday LLC	AE	ACTIVE	\N	LLC	\N	\N	\N	n@nnn.com	0509090909	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_b4a942dbec2248738e32789d95fb2172	2025-10-30 17:23:08.25232	2025-10-30 17:23:06.578533	$2b$12$E2L/zNr8lqNMxKpjdJOk9uTVdFSP9F5pnaTuIr1G9SqxUSByMj4dC	\N	\N	INVOICE_COUNT	\N	100	2025-10-31 05:48:24.517561	0	plan_free	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_881c54ba	Test AWS SES	AE	REJECTED	\N	LLC	\N	\N	\N	nrashidk+test@gmail.com	0509999888	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_5548e80b5547422d909aa17c254f15d5	2025-10-30 09:04:01.46799	2025-10-30 09:03:59.824188	$2b$12$VhQ4KXSbtaU7g59wn/s/D.LX8tpYy5wR./Dl5xVUu0F12eVr19u3y	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_1de50b19	\N	AE	REJECTED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Dubai	\N	\N	\N	\N	\N	f	\N	\N	2025-10-24 18:58:04.661304	\N	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_f69a4ff5	Test 31	AE	ACTIVE	\N	LLC	\N	\N	\N	retro_lounge@hotmail.com	0501231231	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_689f611e1cf74548a778947c57629a75	2025-10-31 05:44:20.924103	2025-10-31 05:44:17.992425	$2b$12$WdsajST2M3zUqXWsWBj./.IohgKrF4GngvhFpDpenehmSHmzcXCk.	\N	\N	INVOICE_COUNT	\N	1000	2025-10-31 06:01:48.525511	0	plan_free	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_35194978	New Test Company	AE	REJECTED	\N	LLC	\N	\N	\N	30oct@new.com	0509999888	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-30 03:55:24.015843	$2b$12$XTX0qIEsMvDjViMzc.nxwud0aMnKJiNzEECUsyG6o1rU9PVN/2dk6	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_d1297e64	E2E Test Company LLC	AE	REJECTED	100234567890003	Technology	\N	\N	\N	testuser@involinks.ae	+971501234567	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025-10-27 18:55:01.709571	$2b$12$vh6Ye35JTqtQl7ImUZWeqOjXP1/qCGSlFIwyTNz8eu9Km.K6ZnXYG	\N	\N	\N	\N	\N	\N	5	\N	f	\N	\N	\N	\N	\N	ACTIVE	2025-10-29 19:19:25.774938	1	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_016e80ee	New Test Co	AE	PENDING_REVIEW	\N	\N	\N	\N	\N	newtest@example.com	971501234567	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_9a1377de9b904d14b4990dcfa64b19bf	2025-10-31 22:39:39.851414	2025-10-31 22:39:38.180741	$2b$12$bMhHYIwH/xVbbO7fQalSZOOOEiSCQEziZWLPnncpEIpc2sbqyMD.G	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_9b3ade33	test	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	test21@yopmail.com	1234567890	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_d7140bfa024e4e60a6c664dc4397d05e	2025-11-21 10:23:04.596812	2025-11-21 10:23:02.967293	$2b$12$0dF0sFFNZFf87gncbETiZuOJz0.ELtsdQ.9fp.5AgdYxbBNgtGO/G	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_49d952ac	test	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	namit10@yopmail.com	1234567890	www.www.com	test floor	test area	sharjah	Sharjah	00000	\N	\N	\N	\N	f	verify_1bc4f2e39ac54081a208fbaf7b73782d	2025-11-10 05:58:38.024654	2025-11-10 05:58:36.391447	$2b$12$ssyOmcBJNPjc.nImcd0lCO68XbLFDkn2WjVl6P66aqzaDKPUFcfeW	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_43297d57	Mcode	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	namit.mcodeinfosoft@gmail.com	1234567898	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_92d1c1d6997c472d92ec555ceb7e60a2	2025-11-21 10:26:24.594619	2025-11-21 10:26:21.734354	$2b$12$iJurYwgbDWjRYP3bNyBiDenM3eMdzlzL9dvKV38gmY/jV.yHJI4MO	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_872df1f2	test	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	test12@gmail.com	1234567898	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_d0cff6ba9c0c4a8e93d18524d0efa5fb	2025-11-21 10:28:39.546467	2025-11-21 10:28:37.942727	$2b$12$4OPAfxh8t8InMwWL.BhKWuXq0.q8L5oubnmEYWq.dNyTDqHGJ0JrW	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_6e6acf00	Test 1	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	nn@nn.com	0501234123	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_7541f65baab549a2a45b2263e1ec568d	2025-11-22 17:59:16.184779	2025-11-22 17:59:14.457222	$2b$12$GwpGjZjiDEtd6P2qg/43NOnPpV3WLA1OX57YQS1yEAEfXWcCcRJOW	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_14b95c8d	namit_test	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	namitsuper@yopmail.com	4563210201	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_cc00457202844550ae79ce0796ee98f5	2026-02-02 06:33:29.637872	2026-02-02 06:33:26.840608	$2b$12$Tr312921zAMBwnOfzc2ZUeXx0RKyHJnY0bbJ.4cmt4JQtVFFMyqfi	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_43fc8468	Namit-code	AE	ACTIVE	123456789012345	LLC	\N	\N	\N	namittest@yopmail.com	1234567898	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_1d4d46c80c91428b83b6c46bbc839ac6	2025-11-21 07:16:45.075756	2025-11-21 07:16:43.426393	$2b$12$LceuCurFy2QPw.S.NRUI9uRk4tleAIMChZol9jZAazNCeczAcWYi2	\N	\N	\N	\N	\N	\N	2	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	7	\N	\N	f	\N	\N	\N	\N	\N	\N	t	2026-02-04	\N	\N	\N
co_c6cb7ade	test	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	333333@test.com	1234567899	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_ac74cc88e77d4f3bba8263348d26b7af	2026-03-03 04:46:40.320238	2026-03-03 04:46:40.277148	$2b$12$nUV92Pw2AUoVQ7H52eAm..CylxhYsxjOPRbaW6/SdEX.5BCag.DPa	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_5de0fac6	test	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	332333@test.com	1234567899	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_f363e9c3174e4acc948f36063615d4e9	2026-03-03 04:47:31.547515	2026-03-03 04:47:31.539449	$2b$12$cAxNGgPjGIma.Wcn4SS/LuoSRVIxUIDfM16PZy5qM2LHjbLFbucGS	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_09da6f57	test	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	3323333@test.com	1234567899	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_6580dc162b494f41a5fffccf86b024df	2026-03-03 05:25:27.100292	2026-03-03 05:25:26.935786	$2b$12$xk44j07fvSA8pP42BSFZkOLyoE1tFpo8jLlTBd87cIs3eXC2.IHRm	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_9e4115b3	test	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	3354454@test.com	1234567899	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_cb4eb8df81144c17a59c9c2046ccd3d5	2026-03-03 05:29:08.847396	2026-03-03 05:29:08.807807	$2b$12$5G9gd6VAUy96GSnwAbqYxOPYT6W3s/ZPPXA4Mn8Ttfop5Jf68Fr.m	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_b7da8f92	test	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	test323323@yopmail.com	1234567899	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_eea42470b0214bda8e8dacf5226afa19	2026-03-03 06:04:37.271663	2026-03-03 06:04:36.966446	$2b$12$bhBRBXsB/RXelWQlUgLT9O.rykZKrg1EBUrQJmd0fcneFRy5guufi	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_d52ef7a5	200 test	AE	PENDING_REVIEW	\N	LLC	\N	\N	\N	200@test.com	0502002002	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	verify_a0fe2da3dc2d4335b1699aacc9699d1e	2026-03-26 15:55:34.828002	2026-03-26 15:55:34.787967	$2b$12$74/07lLJrv9EIh8k7g7bmuABTTvWU02lOQ/iSiDpEF8rcCJd9wk66	\N	\N	\N	\N	\N	\N	0	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	0	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
co_f73de616	VAT Test Co	AE	ACTIVE	100123456700003	\N	\N	\N	\N	vattest@involinks.test	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	verify_6b897f16c5ef4c7899b62bcf3d5c9dcf	2026-03-27 21:31:23.44255	2026-03-27 21:31:23.430286	$2b$12$t7D08LGH/GAoevbYUXIaxu27lRwzzFHyQOTtrYBdJs2ld9.PXIMfG	\N	\N	\N	\N	\N	\N	8	\N	f	\N	\N	\N	\N	\N	ACTIVE	\N	8	\N	\N	f	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
\.


--
-- Data for Name: company_branding; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_branding (id, company_id, logo_file_name, logo_file_path, logo_file_size, logo_mime_type, logo_uploaded_at, stamp_file_name, stamp_file_path, stamp_file_size, stamp_mime_type, stamp_uploaded_at, primary_color, secondary_color, font_family, created_at, updated_at) FROM stdin;
br_5c8e69c0	co_d1297e64	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-29 20:52:06.408374	2025-10-29 20:53:24.480307
br_d7a32515	co_49d952ac	logo.png	/home/runner/workspace/artifacts/branding/co_49d952ac/logo.png	31715	image/png	2025-11-10 09:30:55.796861	\N	\N	\N	\N	\N	\N	\N	\N	2025-11-10 06:10:03.265755	2025-11-11 04:53:47.572675
br_e928df04	co_43fc8468	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-05 09:52:13.961206	2026-02-06 05:52:50.613407
\.


--
-- Data for Name: company_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_documents (id, company_id, document_type, file_name, file_path, file_size, mime_type, status, issue_date, expiry_date, document_number, uploaded_at) FROM stdin;
\.


--
-- Data for Name: company_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company_subscriptions (id, company_id, plan_id, status, billing_cycle, current_period_start, current_period_end, invoices_this_period, created_at) FROM stdin;
sub_1886cc5a	co_333cf1dd	plan_free	ACTIVE	monthly	2025-10-24	2026-10-24	0	2025-10-24 18:09:56.615133
sub_535a7621	co_862e31fc	plan_free	ACTIVE	monthly	2025-10-24	2026-10-24	0	2025-10-24 18:23:57.130422
sub_09ff1725	co_ae587f9d	plan_free	ACTIVE	monthly	2025-10-24	2026-10-24	0	2025-10-24 19:00:57.38019
\.


--
-- Data for Name: content_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_blocks (id, key, value, description, section, updated_at, updated_by) FROM stdin;
cb_52954604982a	homepage_hero_title	Simple, Compliant\nDigital Invoicing for UAE	Homepage main heading	homepage	2025-10-28 15:29:18.959942	system
cb_3e6ecfee9d65	homepage_hero_subtitle	Automated invoicing in structured electronic formats.	Homepage subheading	homepage	2025-10-28 15:29:18.959945	system
cb_7af8c29dd459	feature_box_1_title	Government-Approved Invoices	First feature box title	feature_boxes	2025-10-28 15:29:18.959947	system
cb_d0863a02c612	feature_box_1_description	Create professional invoices that meet all UAE government requirements. Every invoice is automatically secured and properly formatted.	First feature box description	feature_boxes	2025-10-28 15:29:18.959947	system
cb_b91a1687a683	feature_box_3_title	Extra Security	Third feature box title	feature_boxes	2025-10-28 15:29:18.959952	system
cb_c38e48cd4df8	feature_box_3_description	Extra protection for your account. Use your phone or email to confirm it's really you when logging in.	Third feature box description	feature_boxes	2025-10-28 15:29:18.959953	system
cb_9409381b1733	feature_box_4_title	Team Collaboration	Fourth feature box title	feature_boxes	2025-10-28 15:29:18.959953	system
cb_346a2b5eba02	feature_box_4_description	Work together with your team. Add unlimited members and control who can view or edit invoices.	Fourth feature box description	feature_boxes	2025-10-28 15:29:18.959954	system
cb_c572531ffbc5	feature_box_5_title	Electronic Delivery	Fifth feature box title	feature_boxes	2025-10-28 15:29:18.959954	system
cb_5b035dba1122	feature_box_5_description	Send invoices electronically to your customers through trusted partners, making delivery fast and secure.	Fifth feature box description	feature_boxes	2025-10-28 15:29:18.959955	system
cb_54929fdf1a8b	feature_box_6_title	Flexible Subscriptions	Sixth feature box title	feature_boxes	2025-10-28 15:29:18.959955	system
cb_8b85ac431986	feature_box_6_description	Start free with 10 invoices per month. Upgrade anytime as your business grows to send unlimited invoices.	Sixth feature box description	feature_boxes	2025-10-28 15:29:18.959956	system
cb_601ae07d55c2	feature_box_2_title	Manage Inventory & Suppliers	Second feature box title	feature_boxes	2025-10-31 17:53:29.138016	system@involinks.ae
cb_cb78335e3217	feature_box_2_description	Track your stock, manage supplier details, and link purchase orders with invoices for accurate reconciliation.	Second feature box description	feature_boxes	2025-10-31 17:53:32.637782	system@involinks.ae
255c28f0-9738-497c-b489-a0d7179ddbad	header_company_name	InvoLinks	Company name displayed in header	header	2025-10-31 18:00:06.896186	system@involinks.ae
648d6970-6bb7-4cd7-9b11-f68038c05f7e	header_tagline	UAE E-Invoicing Platform	Tagline displayed in header	header	2025-10-31 18:00:06.896186	system@involinks.ae
4a40e220-91ea-4b31-830a-465360ce9f3f	footer_company_name	InvoLinks	Company name in footer	footer	2025-10-31 18:00:06.896186	system@involinks.ae
00f41d0e-6c70-424a-aa97-42798383a0d3	footer_description	Professional e-invoicing solution for UAE businesses. Compliant with FTA regulations.	Footer description text	footer	2025-10-31 18:00:06.896186	system@involinks.ae
f539477f-5077-41ed-b916-e425ce6a8302	footer_copyright	© 2025 InvoLinks. All rights reserved.	Copyright notice	footer	2025-10-31 18:00:06.896186	system@involinks.ae
71c487a4-8889-45fa-a4bc-6b76fd1bbd0b	footer_email	support@involinks.ae	Support email address	footer	2025-10-31 18:00:06.896186	system@involinks.ae
fac652f2-bc1c-428f-9de1-1df6dcec9cc3	footer_phone	+971 XX XXX XXXX	Contact phone number	footer	2025-10-31 18:00:06.896186	system@involinks.ae
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.expense_categories (id, company_id, name, description, is_default, created_at) FROM stdin;
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.expenses (id, company_id, expense_date, category, description, amount, vat_amount, total_amount, currency_code, reference_number, supplier_name, notes, created_at, updated_at, tax_code, vendor_id, created_by_user_id) FROM stdin;
\.


--
-- Data for Name: featured_businesses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.featured_businesses (id, company_id, display_name, logo_url, is_active, display_order, added_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: goods_receipt_line_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.goods_receipt_line_items (id, grn_id, po_line_item_id, line_number, item_name, item_code, quantity_received, quantity_accepted, quantity_rejected, unit_code, condition, notes, created_at) FROM stdin;
\.


--
-- Data for Name: goods_receipts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.goods_receipts (id, company_id, po_id, grn_number, status, receipt_date, received_by_user_id, supplier_trn, supplier_name, supplier_delivery_note, total_items_received, total_value, inspection_passed, quality_notes, damaged_items_count, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: integrity_checks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integrity_checks (id, company_id, performed_by_user_id, checked_at, total_invoices, valid_links, integrity_ok, first_broken_invoice_id, first_broken_invoice_number, first_broken_invoice_date) FROM stdin;
ic_020bc574e0fa4d84	\N	user_60763c2b	2026-03-28 13:34:06.795279	15	0	f	inv_4229479d9cee	INV-202510-0003	2025-10-27
ic_250077b00f2040bb	\N	user_60763c2b	2026-03-28 13:38:44.481767	15	3	f	inv_887e97dea8e0	INV-202510-0005	2025-10-27
ic_27671e0e02b348f6	\N	user_60763c2b	2026-03-28 13:43:51.239451	15	0	f	inv_da20971fd45b	INV-202510-0002	2025-10-27
ic_7e61afaed3814e1a	\N	user_60763c2b	2026-03-28 13:48:18.341228	15	3	f	inv_da20971fd45b	INV-202510-0002	2025-10-27
ic_52755d15964b4103	\N	user_60763c2b	2026-03-28 13:52:39.802139	9	3	f	inv_887e97dea8e0	INV-202510-0005	2025-10-27
ic_5b9bb91da1974f0e	\N	user_60763c2b	2026-03-28 13:55:12.745083	5	1	f	inv_dc120af00337	INV-202510-0008	2025-10-29
ic_fc1cda29cb20496a	\N	user_60763c2b	2026-03-28 13:58:27.197535	15	3	f	inv_da20971fd45b	INV-202510-0002	2025-10-27
ic_48b4b4276e544b09	\N	user_60763c2b	2026-03-28 14:01:16.410004	9	3	f	inv_887e97dea8e0	INV-202510-0005	2025-10-27
ic_a497b2ac84164118	\N	user_60763c2b	2026-03-28 14:04:15.102617	9	3	f	inv_887e97dea8e0	INV-202510-0005	2025-10-27
ic_df681f4747414d2f	\N	user_60763c2b	2026-03-28 14:08:06.449436	9	3	f	inv_887e97dea8e0	INV-202510-0005	2025-10-27
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_items (id, company_id, item_name, item_code, description, unit, current_stock, min_stock_level, unit_cost, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_transactions (id, company_id, inventory_item_id, transaction_type, quantity, transaction_date, reference_type, reference_id, notes, stock_after, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_line_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_line_items (id, invoice_id, line_number, item_name, item_description, item_code, quantity, unit_code, unit_price, line_extension_amount, tax_category, tax_percent, tax_amount, line_total_amount, created_at, tax_code) FROM stdin;
line_c0943226a6b6	inv_46e3984bfc91	1	Professional Services	Consulting services	\N	10	C62	500	5000	STANDARD	5	250	5250	2025-10-27 19:23:58.74075	SR
line_ac32da52e06c	inv_da20971fd45b	1	Consulting Services	Technical consulting	\N	20	C62	1000	20000	STANDARD	5	1000	21000	2025-10-27 19:26:49.910189	SR
line_b5bf7d3b8c6a	inv_4229479d9cee	1	Service	Test	\N	1	C62	1000	1000	STANDARD	5	50	1050	2025-10-27 19:28:55.062326	SR
line_30d78f257011	inv_1c757bc81022	1	Service	Test	\N	1	C62	1000	1000	STANDARD	5	50	1050	2025-10-27 20:04:53.021007	SR
line_901f8fcc5431	inv_887e97dea8e0	1	Service	Test	\N	1	C62	1000	1000	STANDARD	5	50	1050	2025-10-27 20:11:49.048106	SR
line_301f6882550b	inv_83337bdd79d9	1	Service	Test	\N	1	C62	1000	1000	STANDARD	5	50	1050	2025-10-27 20:15:03.448611	SR
line_9a0e6771ae12	inv_644686a09765	1	Item	Test	\N	1	C62	100	100	STANDARD	5	5	105	2025-10-27 20:15:39.807977	SR
line_547981b3c646	inv_dc120af00337	1	"Professional Services"		\N	1	C62	1000	1000	STANDARD	5	50	1050	2025-10-29 19:19:27.898578	SR
line_0aa8aa0d5fe9	inv_d20d7063347d	1	Test		\N	1	C62	1	1	OUT_OF_SCOPE	0	0	1	2026-02-03 08:51:52.778811	SR
line_2e4f4751de3c	inv_9b3322b5b437	1	Test		\N	1	C62	100	100	OUT_OF_SCOPE	0	0	100	2026-02-03 10:01:19.053748	SR
line_5dd99ff69c49	inv_8aa8674436d5	1	Test		\N	1	C62	1	1	STANDARD	5	0.05	1.05	2026-02-03 13:21:33.005211	SR
line_6c62659f4a19	inv_496771bf070a	1	Test		\N	1	C62	1	1	STANDARD	5	0.05	1.05	2026-02-03 13:23:59.382969	SR
line_4d76be85425b	inv_145d7d412b25	1	test		\N	1	C62	10	10	STANDARD	5	0.5	10.5	2026-02-03 14:07:59.619484	SR
line_93f7e5d83e2d	inv_36b483ccbd9f	1	test		\N	1	C62	0	0	STANDARD	5	0	0	2026-02-04 04:45:02.886949	SR
line_bd56aea9fc3e	inv_661c58f0941d	1	Test-item		\N	100	C62	20	2000	OUT_OF_SCOPE	5	0	2000	2026-02-04 05:19:06.74509	SR
line_4bdf4bae6409	inv_7faa83b485f7	1	Test Service	\N	\N	1	C62	100	100	OUT_OF_SCOPE	0	0	100	2026-03-28 19:19:07.509728	OP
line_a36ea1550f8d	inv_5689c2fdb71f	1	Consulting	\N	\N	1	C62	100	100	OUT_OF_SCOPE	0	0	100	2026-03-28 19:21:02.230835	OP
line_7b8f3e770308	inv_056bd5f804d7	1	Item	\N	\N	2	C62	500	1000	OUT_OF_SCOPE	0	0	1000	2026-03-28 19:21:02.408456	OP
line_88756289201d	inv_9c1648f5b3cf	1	Item	\N	\N	1	C62	100	100	OUT_OF_SCOPE	0	0	100	2026-03-28 19:30:51.608061	OP
li_c27195f7f1f2	inv_d1441d4f812f	1	Item	\N	\N	1	C62	150	150	STANDARD	5	7.5	157.5	2026-03-28 19:31:28.799607	SR
li_4bf5baf8f110	inv_f8a538c1bd0d	1	Item	\N	\N	2	C62	200	400	STANDARD	5	20	420	2026-03-28 19:32:45.381004	SR
line_60e2651cd6f5	inv_76007b2e633c	1	Service	\N	\N	1	C62	1000	1000	OUT_OF_SCOPE	0	0	1000	2026-03-28 19:32:45.541944	OP
li_21f40d39f47c	inv_42a5aa5c8086	1	X	\N	\N	1	C62	100	100	STANDARD	5	5	105	2026-03-28 19:36:47.435106	SR
\.


--
-- Data for Name: invoice_tax_breakdowns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_tax_breakdowns (id, invoice_id, tax_category, taxable_amount, tax_percent, tax_amount, created_at) FROM stdin;
tax_eb04b8e1f84b	inv_46e3984bfc91	STANDARD	5000	5	250	2025-10-27 19:23:58.981851
tax_13a162b07d70	inv_da20971fd45b	STANDARD	20000	5	1000	2025-10-27 19:26:50.155231
tax_2317a073e7db	inv_4229479d9cee	STANDARD	1000	5	50	2025-10-27 19:28:55.30604
tax_b220c5f9cb0b	inv_1c757bc81022	STANDARD	1000	5	50	2025-10-27 20:04:53.255436
tax_3c6079d8fcd2	inv_887e97dea8e0	STANDARD	1000	5	50	2025-10-27 20:11:49.304808
tax_ce892f7bcfa1	inv_83337bdd79d9	STANDARD	1000	5	50	2025-10-27 20:15:03.696571
tax_60f04d8460bd	inv_644686a09765	STANDARD	100	5	5	2025-10-27 20:15:40.047397
tax_f58c62354da8	inv_dc120af00337	STANDARD	1000	5	50	2025-10-29 19:19:28.138469
tax_97b6baf783d4	inv_d20d7063347d	OUT_OF_SCOPE	1	0	0	2026-02-03 08:51:53.01686
tax_785e5fc60be1	inv_9b3322b5b437	OUT_OF_SCOPE	100	0	0	2026-02-03 10:01:19.291748
tax_7445163be00a	inv_8aa8674436d5	STANDARD	1	5	0.05	2026-02-03 13:21:33.245358
tax_88927b6a8df1	inv_496771bf070a	STANDARD	1	5	0.05	2026-02-03 13:23:59.617429
tax_d0b960edf005	inv_145d7d412b25	STANDARD	10	5	0.5	2026-02-03 14:07:59.858067
tax_f4fbd1944daa	inv_36b483ccbd9f	STANDARD	0	5	0	2026-02-04 04:45:03.129431
tax_99d23eb8544a	inv_661c58f0941d	OUT_OF_SCOPE	2000	5	0	2026-02-04 05:19:06.982598
tb_66de942a884c	inv_d1441d4f812f	STANDARD	150	5	7.5	2026-03-28 19:31:28.802875
tb_98d8cf8c7cce	inv_f8a538c1bd0d	STANDARD	400	5	20	2026-03-28 19:32:45.383632
tb_92f36d057e02	inv_42a5aa5c8086	STANDARD	100	5	5	2026-03-28 19:36:47.437809
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, company_id, invoice_number, invoice_type, status, issue_date, due_date, currency_code, supplier_trn, supplier_name, supplier_address, supplier_city, supplier_country, supplier_peppol_id, customer_trn, customer_name, customer_email, customer_address, customer_city, customer_country, customer_peppol_id, subtotal_amount, tax_amount, total_amount, amount_due, total_amount_aed, payment_terms, payment_due_days, invoice_notes, reference_number, preceding_invoice_id, credit_note_reason, xml_file_path, pdf_file_path, xml_hash, share_token, sent_at, viewed_at, paid_at, created_at, updated_at, prev_invoice_hash, signature_b64, signing_cert_serial, signing_timestamp, peppol_message_id, peppol_status, peppol_provider, peppol_sent_at, peppol_response, tax_code, invoice_classification, created_by_user_id, payment_verified_by_user_id, payment_verified_at, payment_method, debit_note_reason, supply_date, version, is_archived, archived_at) FROM stdin;
inv_46e3984bfc91	co_d1297e64	INV-202510-0001	TAX_INVOICE	DRAFT	2025-10-27	2025-11-27	AED	100234567890003	E2E Test Company LLC	\N	\N	AE	1002345678	\N	Acme Corporation	billing@acme.com	Dubai, UAE	\N	AE	\N	5000	250	5250	5250	5250	Net 30	30	\N	\N	\N	\N	\N	\N	\N	share_b6845c11407d47b4	\N	\N	\N	2025-10-27 19:23:58.258679	2025-10-27 19:23:58.503359	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_661c58f0941d	co_43fc8468	INV-202602-0007	COMMERCIAL_INVOICE	CANCELLED	2026-02-04	2026-03-06	AED	\N	Namit-code	\N	\N	AE	\N	100010010010000	Test user	test@yopmail.com	bestech	mohali	AE	\N	2000	0	2000	2000	2000	\N	30	testing the notes		\N	\N	\N	\N	\N	share_7c0bdd1a949c44c6	\N	\N	\N	2026-02-04 05:19:06.037809	2026-02-04 05:21:32.645338	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_da20971fd45b	co_d1297e64	INV-202510-0002	TAX_INVOICE	ISSUED	2025-10-27	2025-11-27	AED	100234567890003	E2E Test Company LLC	\N	\N	AE	1002345678	\N	Test Customer Ltd	customer@test.com	123 Business St, Dubai, UAE	\N	AE	\N	20000	1000	21000	21000	21000	Net 30	30	\N	\N	\N	\N	invoices_xml/INV-202510-0002.xml	\N	30ad3032be4e6473fcc50df2a02962c3f21b960b279687773eff8d3101f5987a	share_bda8d2d802e74bf3	\N	\N	\N	2025-10-27 19:26:49.418321	2025-10-27 19:26:54.173824	\N	TU9DSy1TSUdOQVRVUkUtY2UxOWMxZmNjYzk4ODQzYzk2NDYxOTU4Y2UxOGJjNDY=	MOCK-CERT-001	2025-10-27 19:26:53.694026	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_dc120af00337	co_d1297e64	INV-202510-0008	TAX_INVOICE	ISSUED	2025-10-29	2025-11-28	AED	100234567890003	E2E Test Company LLC	\N	\N	AE	1002345678		Test Customer LLC	test@n.com	UAQ	UAQ	AE	\N	1000	50	1050	1050	1050	\N	30	UAQ		\N	\N	invoices_xml/INV-202510-0008.xml	\N	8fe81ef88ec7bcdbb694a7b1d2fe18d380f4dd41179d21c583163c6afe4c1b8c	share_655ef12b71f94c79	\N	\N	\N	2025-10-29 19:19:27.189361	2025-10-29 19:22:55.39645	c30eab478d191df561a0a2e54f5f17a9888ef05956dcb82c5dd8e1b826777c0e	TU9DSy1TSUdOQVRVUkUtZDcyNWRkZDEzY2VhZTZlYjc5MWRmN2UwNTIzMzNmMDA=	MOCK-CERT-001	2025-10-29 19:22:54.916901	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_4229479d9cee	co_d1297e64	INV-202510-0003	TAX_INVOICE	ISSUED	2025-10-27	2025-11-27	AED	100234567890003	E2E Test Company LLC	\N	\N	AE	1002345678	\N	Final Test Corp	test@test.com	Dubai	\N	AE	\N	1000	50	1050	1050	1050	Net 30	30	\N	\N	\N	\N	invoices_xml/INV-202510-0003.xml	\N	d4febf9a1715bf410c22aa08d16a5bbeeb68fa7d375794b03e8a99802930f2ba	share_a1044a9b20824108	\N	\N	\N	2025-10-27 19:28:54.574269	2025-10-27 19:28:59.310945	30ad3032be4e6473fcc50df2a02962c3f21b960b279687773eff8d3101f5987a	TU9DSy1TSUdOQVRVUkUtODNiMDA4MDVkODNmNTVmN2Q5NjI2NDA2YmZhYzY0ZTE=	MOCK-CERT-001	2025-10-27 19:28:58.834972	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_d20d7063347d	co_43fc8468	INV-202602-0001	COMMERCIAL_INVOICE	DRAFT	2026-02-03	2026-03-05	AED	\N	Namit-code	\N	\N	AE	\N		TEST				AE	\N	1	0	1	1	1	\N	30			\N	\N	\N	\N	\N	share_efe52393adb946b3	\N	\N	\N	2026-02-03 08:51:52.074827	2026-02-03 08:51:52.547245	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_1c757bc81022	co_d1297e64	INV-202510-0004	TAX_INVOICE	CANCELLED	2025-10-27	2025-11-27	AED	100234567890003	E2E Test Company LLC	\N	\N	AE	1002345678	\N	Test Customer	test@test.com	Dubai	\N	AE	\N	1000	50	1050	1050	1050	Net 30	30	\N	\N	\N	\N	invoices_xml/INV-202510-0004.xml	\N	8f1f8ca5fb450d2a9938f0871f33e7d4924179d9030a8e144d7661fadccca1a7	share_d13aae82e51246b0	\N	\N	\N	2025-10-27 20:04:52.550589	2025-10-27 20:05:02.224408	d4febf9a1715bf410c22aa08d16a5bbeeb68fa7d375794b03e8a99802930f2ba	TU9DSy1TSUdOQVRVUkUtNWVjNzAzMDEyZGE3MzE4NTg4YjYyMTAwYTAxNzU3OWE=	MOCK-CERT-001	2025-10-27 20:04:59.423304	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_887e97dea8e0	co_d1297e64	INV-202510-0005	TAX_INVOICE	CANCELLED	2025-10-27	2025-11-27	AED	100234567890003	E2E Test Company LLC	\N	\N	AE	1002345678	\N	Test	test@test.com	Dubai	\N	AE	\N	1000	50	1050	1050	1050	Net 30	30	\N	\N	\N	\N	\N	\N	\N	share_edcc3b0462254792	\N	\N	\N	2025-10-27 20:11:48.532507	2025-10-27 20:11:52.389506	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_83337bdd79d9	co_d1297e64	INV-202510-0006	TAX_INVOICE	DRAFT	2025-10-27	2025-11-27	AED	100234567890003	E2E Test Company LLC	\N	\N	AE	1002345678	\N	Test	test@test.com	Dubai	\N	AE	\N	1000	50	1050	1050	1050	Net 30	30	\N	\N	\N	\N	\N	\N	\N	share_6a6a21009b3b4d5f	\N	\N	\N	2025-10-27 20:15:02.952742	2025-10-27 20:15:03.205334	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_9b3322b5b437	co_43fc8468	INV-202602-0002	COMMERCIAL_INVOICE	DRAFT	2026-02-03	2026-03-05	AED	\N	Namit-code	\N	\N	AE	\N		Nasser Rashid	n@mm.com	Al Nahyan Camp		AE	\N	100	0	100	100	100	\N	30	Test		\N	\N	\N	\N	\N	share_28fd56a3f9a4410e	\N	\N	\N	2026-02-03 10:01:18.353564	2026-02-03 10:01:18.822872	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_644686a09765	co_d1297e64	INV-202510-0007	TAX_INVOICE	CANCELLED	2025-10-27	2025-11-27	AED	100234567890003	E2E Test Company LLC	\N	\N	AE	1002345678	\N	QuickTest	q@t.com	Dubai	\N	AE	\N	100	5	105	105	105	Net 30	30	\N	\N	\N	\N	invoices_xml/INV-202510-0007.xml	\N	c30eab478d191df561a0a2e54f5f17a9888ef05956dcb82c5dd8e1b826777c0e	share_4727a68f51da4078	\N	\N	\N	2025-10-27 20:15:39.325581	2025-10-27 20:15:46.48472	\N	TU9DSy1TSUdOQVRVUkUtMGU0NzBhMjQ2NDI3OWVhNWMzNTU0MDJkNmY1ODRhY2Y=	MOCK-CERT-001	2025-10-27 20:15:43.534208	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_8aa8674436d5	co_43fc8468	INV-202602-0003	COMMERCIAL_INVOICE	DRAFT	2026-02-03	2026-03-05	AED	\N	Namit-code	\N	\N	AE	\N		TEST				AE	\N	1	0.05	1.05	1.05	1.05	\N	30			\N	\N	\N	\N	\N	share_f24568c3c07e47f0	\N	\N	\N	2026-02-03 13:21:32.296074	2026-02-03 13:21:32.771995	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_496771bf070a	co_43fc8468	INV-202602-0004	COMMERCIAL_INVOICE	DRAFT	2026-02-03	2026-03-05	AED	\N	Namit-code	\N	\N	AE	\N		TEST				AE	\N	1	0.05	1.05	1.05	1.05	\N	30			\N	\N	\N	\N	\N	share_9d0b13854e2647b6	\N	\N	\N	2026-02-03 13:23:58.677696	2026-02-03 13:23:59.14987	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_145d7d412b25	co_43fc8468	INV-202602-0005	COMMERCIAL_INVOICE	ISSUED	2026-02-03	2026-03-05	AED	\N	Namit-code	\N	\N	AE	\N		test				AE	\N	10	0.5	10.5	10.5	10.5	\N	30			\N	\N	invoices_xml/INV-202602-0005.xml	\N	087e02ab33b617fc8c51c47289707c1d2e7b672d86aac7e3cd1194b71f016dc4	share_80e046f213194fc2	\N	\N	\N	2026-02-03 14:07:58.915414	2026-02-03 14:08:08.934735	\N	TU9DSy1TSUdOQVRVUkUtYjAxMTM0Njc5ZGM5ZDgzMjg5OGU1YjlmNWQyYTlmNTU=	MOCK-CERT-001	2026-02-03 14:08:08.468931	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_36b483ccbd9f	co_43fc8468	INV-202602-0006	COMMERCIAL_INVOICE	SENT	2026-02-04	2026-03-06	AED	123456789012345	Namit-code	\N	\N	AE	\N		testing				AE	\N	0	0	0	0	0	\N	30			\N	\N	invoices_xml/INV-202602-0006.xml	\N	04dfa5fd93d1088e1d7be9d6593a43e24edf2456289b162888a5aa447e6a3191	share_dc7338e7f5d94f09	2026-02-04 09:21:20.435159	\N	\N	2026-02-04 04:45:02.402658	2026-02-04 09:21:20.678247	\N	TU9DSy1TSUdOQVRVUkUtMzk2ZTBhZmMwNzMwYjA4ODQ2YzJiZDJlMGFmZmI2Y2Q=	MOCK-CERT-001	2026-02-04 08:13:46.250007	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_7faa83b485f7	co_f73de616	TI-00001	TAX_INVOICE	DRAFT	2026-03-28	\N	USD	100123456700003	VAT Test Co	\N	\N	AE	1001234567	\N	Test Customer	\N	\N	\N	AE	\N	100	0	100	100	400	\N	30	\N	\N	\N	\N	\N	\N	\N	share_33b0ff946a04456c	\N	\N	\N	2026-03-28 19:19:07.505004	2026-03-28 19:19:07.508462	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_5689c2fdb71f	co_f73de616	TI-00002	TAX_INVOICE	DRAFT	2026-03-28	\N	EUR	100123456700003	VAT Test Co	\N	\N	AE	1001234567	\N	EU Corp	\N	\N	\N	DE	\N	100	0	100	100	413.25	\N	30	\N	\N	\N	\N	\N	\N	\N	share_39416233170c4f46	\N	\N	\N	2026-03-28 19:21:02.225143	2026-03-28 19:21:02.229187	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_056bd5f804d7	co_f73de616	TI-00003	TAX_INVOICE	DRAFT	2026-03-28	\N	AED	100123456700003	VAT Test Co	\N	\N	AE	1001234567	\N	Local Co	\N	\N	\N	AE	\N	1000	0	1000	1000	1000	\N	30	\N	\N	\N	\N	\N	\N	\N	share_01e4142fd81a4e75	\N	\N	\N	2026-03-28 19:21:02.405631	2026-03-28 19:21:02.407884	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_9c1648f5b3cf	co_f73de616	TI-00004	TAX_INVOICE	DRAFT	2026-03-28	\N	AED	100123456700003	VAT Test Co	\N	\N	AE	1001234567	\N	Test PUT Co	\N	\N	\N	AE	\N	100	0	100	100	100	\N	30	\N	\N	\N	\N	\N	\N	\N	share_ce9d6c13b50e4ed0	\N	\N	\N	2026-03-28 19:30:51.60045	2026-03-28 19:30:51.604925	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_76007b2e633c	co_f73de616	TI-00007	TAX_INVOICE	DRAFT	2026-03-28	\N	AED	100123456700003	VAT Test Co	\N	\N	AE	1001234567	\N	Local AED Co	\N	\N	\N	AE	\N	1000	0	1000	1000	1000	\N	30	\N	\N	\N	\N	\N	\N	\N	share_9c9c8f7d2b894c2b	\N	\N	\N	2026-03-28 19:32:45.539414	2026-03-28 19:32:45.541476	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	1	f	\N
inv_d1441d4f812f	co_f73de616	TI-00005	TAX_INVOICE	DRAFT	2026-03-28	\N	EUR	100123456700003	VAT Test Co	\N	\N	AE	1001234567	\N	Test PUT Co	\N	\N	\N	AE	\N	150	7.5	157.5	157.5	550	\N	30	\N	\N	\N	\N	\N	\N	\N	share_59f505d7d8214357	\N	\N	\N	2026-03-28 19:31:28.547621	2026-03-28 19:31:28.801898	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	2	f	\N
inv_f8a538c1bd0d	co_f73de616	TI-00006	TAX_INVOICE	DRAFT	2026-03-28	\N	EUR	100123456700003	VAT Test Co	\N	\N	AE	1001234567	\N	Test PUT Co	\N	\N	\N	AE	\N	400	20	420	420	450	\N	30	\N	\N	\N	\N	\N	\N	\N	share_78ea76c4fe48499f	\N	\N	\N	2026-03-28 19:32:45.06373	2026-03-28 19:32:45.382796	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	2	f	\N
inv_42a5aa5c8086	co_f73de616	TI-00008	TAX_INVOICE	DRAFT	2026-03-28	\N	EUR	100123456700003	VAT Test Co	\N	\N	AE	1001234567	\N	EU Corp	\N	\N	\N	AE	\N	100	5	105	105	399	\N	30	\N	\N	\N	\N	\N	\N	\N	share_7dea42a320cd40e4	\N	\N	\N	2026-03-28 19:36:47.104457	2026-03-28 19:36:47.436972	\N	\N	\N	\N	\N	\N	\N	\N	\N	SR	standard	\N	\N	\N	\N	\N	\N	2	f	\N
\.


--
-- Data for Name: inward_invoice_line_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inward_invoice_line_items (id, inward_invoice_id, line_number, item_name, item_description, item_code, quantity, unit_code, unit_price, line_extension_amount, tax_category, tax_percent, tax_amount, line_total_amount, po_line_item_id, grn_line_item_id, match_status, created_at) FROM stdin;
ef58a3d8-6a12-470b-b770-b977cb9343b0	d39145ed-c075-4e47-bac6-7f8cf95dd19a	1	Standard Goods	\N	\N	1	C62	1000	1000	STANDARD	5	50	1050	\N	\N	\N	2026-03-27 22:19:11.277322
cd3db106-4900-413d-81a6-16f9e8ab4240	d39145ed-c075-4e47-bac6-7f8cf95dd19a	2	Zero-Rated Import	\N	\N	1	C62	500	500	ZERO	0	0	500	\N	\N	\N	2026-03-27 22:19:11.277324
0f84ed33-1a73-45c3-b498-d2afbb31a459	d39145ed-c075-4e47-bac6-7f8cf95dd19a	3	Exempt Financial	\N	\N	1	C62	300	300	EXEMPT	0	0	300	\N	\N	\N	2026-03-27 22:19:11.277324
f252ad74-dc67-42da-afe7-ace091511cd3	d39145ed-c075-4e47-bac6-7f8cf95dd19a	4	Reverse Charge Outsource	\N	\N	1	C62	200	200	OUT_OF_SCOPE	5	10	210	\N	\N	\N	2026-03-27 22:19:11.277325
\.


--
-- Data for Name: inward_invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inward_invoices (id, company_id, supplier_invoice_number, invoice_type, status, invoice_date, due_date, received_at, supplier_trn, supplier_name, supplier_address, supplier_peppol_id, supplier_company_id, customer_trn, customer_name, currency_code, subtotal_amount, tax_amount, total_amount, amount_due, xml_file_path, pdf_file_path, xml_hash, peppol_message_id, peppol_sender_id, peppol_provider, peppol_received_at, po_id, grn_id, matching_status, po_match_score, grn_match_score, amount_variance, quantity_variance, reviewed_by_user_id, reviewed_at, approved_by_user_id, approved_at, rejection_reason, payment_status, payment_method, paid_amount, paid_at, payment_reference, disputed_at, dispute_reason, dispute_resolved_at, notes, reference_number, created_at, updated_at, total_amount_aed) FROM stdin;
d39145ed-c075-4e47-bac6-7f8cf95dd19a	co_f73de616	SUP-MIXED-001	TAX_INVOICE	RECEIVED	2024-06-15	\N	2026-03-27 22:19:11.271291	100234567890	Mixed Tax Supplier LLC	\N	\N	\N	100123456700003	VAT Test Co	AED	2000	60	2060	2060	\N	\N	\N	\N	\N	\N	\N	\N	\N	NOT_MATCHED	0	0	0	0	\N	\N	\N	\N	\N	PENDING	\N	0	\N	\N	\N	\N	\N	\N	\N	2026-03-27 22:19:11.273413	2026-03-27 22:19:11.273415	2060
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.journal_entries (id, company_id, entry_date, reference_type, reference_id, reference_number, description, is_posted, created_by_user_id, created_at) FROM stdin;
b5d54930-86ca-4400-88d8-fb3ad22758ce	co_f73de616	2024-06-15	PURCHASE	d39145ed-c075-4e47-bac6-7f8cf95dd19a	SUP-MIXED-001	Purchase SUP-MIXED-001 from Mixed Tax Supplier LLC	t	user_8ed5d4b2	2026-03-27 22:19:11.275566
\.


--
-- Data for Name: journal_entry_lines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.journal_entry_lines (id, journal_entry_id, account_id, account_code, account_name, debit_amount, credit_amount, currency, amount_aed, description, line_number) FROM stdin;
1b4992e4-4554-4405-95db-721dbffb4b9f	b5d54930-86ca-4400-88d8-fb3ad22758ce	c35f0652-b121-4e20-b99d-1d7c6c268235	4000	Purchase / Cost of Goods	2000	0	AED	2000	Purchase cost	1
8a9cea82-6cb5-4830-b47b-77bdb54ec1aa	b5d54930-86ca-4400-88d8-fb3ad22758ce	60e847f8-c813-40b9-a2a3-7d914b2588ce	1200	VAT Receivable	60	0	AED	60	Input VAT	2
4a244f9d-f2bf-4ab9-abc2-623205f2154a	b5d54930-86ca-4400-88d8-fb3ad22758ce	d44087c4-661c-4d30-820f-7cdf8a484e33	2100	Accounts Payable	0	2060	AED	2060	AP credit	3
\.


--
-- Data for Name: password_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_history (id, user_id, password_hash, created_at) FROM stdin;
ph_09cee1f191244065	usr_29fc7fbf8944	$2b$12$hGWhR8US.UVrdkx0kNvv5ugMpcM7K6LmlCqHOA/5XXcU.YJ6J1IjC	2026-03-28 11:46:01.362787
ph_c903aaf549014874	usr_13ce12ffa251	$2b$12$eeyzGxObY/chmbCMRaUK.OWZvp1a9MeVK021bpnK/dD1F4j1OSe6W	2026-03-28 11:54:37.944818
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_methods (id, company_id, stripe_payment_method_id, card_brand, card_last4, exp_month, exp_year, billing_email, billing_name, is_default, created_at) FROM stdin;
\.


--
-- Data for Name: peppol_usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.peppol_usage (id, company_id, invoice_id, transmission_date, status, fee_amount, month_year, billed, created_at) FROM stdin;
\.


--
-- Data for Name: purchase_order_line_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_order_line_items (id, po_id, line_number, item_name, item_description, item_code, quantity_ordered, quantity_received, unit_code, unit_price, line_total, tax_category, tax_percent, created_at) FROM stdin;
69101567-7063-4028-bcd9-b5540e810480	29efdbe0-0b15-4546-bb84-f0d6ad1a5225	1	First-Item	\N	\N	1	0	C62	0	0	STANDARD	5	2026-02-04 08:09:55.654544
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_orders (id, company_id, po_number, status, supplier_trn, supplier_name, supplier_contact_email, supplier_address, supplier_peppol_id, order_date, expected_delivery_date, delivery_address, currency_code, expected_subtotal, expected_tax, expected_total, received_invoice_count, matched_invoice_count, received_amount_total, variance_amount, reference_number, notes, approved_by_user_id, approved_at, created_at, updated_at) FROM stdin;
29efdbe0-0b15-4546-bb84-f0d6ad1a5225	co_43fc8468	PO-2025-4111	SENT	\N	Acme coporation	\N	\N	\N	2026-02-04	\N	\N	AED	0	0	0	0	0	0	0	\N	\N	\N	\N	2026-02-04 08:09:55.422677	2026-02-04 08:10:10.507428
\.


--
-- Data for Name: registration_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registration_progress (id, company_id, current_step, step_company_info, step_business_details, step_documents, step_plan_selection, step_review, completed, created_at) FROM stdin;
prog_aaa2cd49	co_1800c65a	1	f	f	f	f	f	f	2025-10-24 18:06:10.059831
prog_f42c63f8	co_333cf1dd	3	t	t	f	f	f	t	2025-10-24 18:08:21.033226
prog_489e318f	co_142451f3	1	f	f	f	f	f	f	2025-10-24 18:23:06.465957
prog_cca36486	co_862e31fc	3	t	t	f	f	f	t	2025-10-24 18:23:26.580978
prog_97583272	co_1de50b19	3	f	t	f	f	f	f	2025-10-24 18:58:05.119902
prog_c712e843	co_5a372f9d	3	f	t	f	f	f	f	2025-10-24 18:59:21.472146
prog_ed1cdb1e	co_ae587f9d	3	t	t	f	f	f	t	2025-10-24 19:00:46.731037
prog_4280758b	co_1e52b1c3	1	f	f	f	f	f	f	2025-10-24 20:00:42.631233
prog_832a0e5f	co_40b90d3a	1	f	f	f	f	f	f	2025-10-24 20:47:05.205529
prog_fc4ee7ee	co_2312b3d8	1	f	f	f	f	f	f	2025-10-24 20:47:17.42616
prog_1cbad7a0	co_7b711239	1	t	f	f	f	f	f	2025-10-24 22:04:51.619496
prog_15634675	co_148bde71	1	t	f	f	f	f	f	2025-10-24 22:05:11.616617
prog_46b810ec	co_ecdeb90e	1	t	f	f	f	f	f	2025-10-24 22:06:06.904687
prog_1a2f1d9c	co_580c550f	1	t	f	f	f	f	f	2025-10-25 11:27:31.18107
prog_891f6c8d	co_548156b4	1	t	f	f	f	f	f	2025-10-26 06:30:28.676904
prog_9f47def3	co_0afc5ba3	1	t	f	f	f	f	f	2025-10-26 10:58:24.325317
prog_a95d77f4	co_ef916725	1	t	f	f	f	f	f	2025-10-26 17:50:25.544882
prog_149f1b54	co_d1297e64	1	t	f	f	f	f	f	2025-10-27 18:55:02.19837
prog_d6d02966	co_158975c0	1	t	f	f	f	f	f	2025-10-27 19:09:05.492839
prog_8ddca366	co_ef6032c1	1	t	f	f	f	f	f	2025-10-28 06:26:49.979838
prog_b0187ca7	co_7e575f3d	1	t	f	f	f	f	f	2025-10-28 08:05:16.801907
prog_2abb95c5	co_35194978	1	t	f	f	f	f	f	2025-10-30 03:55:24.59428
prog_d967b8e5	co_881c54ba	1	t	f	f	f	f	f	2025-10-30 09:04:00.304025
prog_1f3549d5	co_a0c89b23	1	t	f	f	f	f	f	2025-10-30 17:23:07.073273
prog_cd1e0e91	co_f69a4ff5	1	t	f	f	f	f	f	2025-10-31 05:44:18.497808
prog_d7a20522	co_016e80ee	1	t	f	f	f	f	f	2025-10-31 22:39:38.668191
prog_da59ddca	co_49d952ac	1	t	f	f	f	f	f	2025-11-10 05:58:36.855653
prog_6d7c623f	co_5906d43b	1	t	f	f	f	f	f	2025-11-19 05:01:14.086628
prog_b012b474	co_43fc8468	1	t	f	f	f	f	f	2025-11-21 07:16:43.903556
prog_ebf51cb4	co_9b3ade33	1	t	f	f	f	f	f	2025-11-21 10:23:03.437533
prog_f7c90d19	co_43297d57	1	t	f	f	f	f	f	2025-11-21 10:26:22.214783
prog_5a16e6dc	co_872df1f2	1	t	f	f	f	f	f	2025-11-21 10:28:38.402255
prog_43b3b3e8	co_6e6acf00	1	t	f	f	f	f	f	2025-11-22 17:59:14.952072
prog_4001bea9	co_14b95c8d	1	t	f	f	f	f	f	2026-02-02 06:33:27.312379
prog_73db676f	co_c6cb7ade	1	t	f	f	f	f	f	2026-03-03 04:46:40.283052
prog_6658d5d9	co_5de0fac6	1	t	f	f	f	f	f	2026-03-03 04:47:31.540815
prog_cad7fedc	co_09da6f57	1	t	f	f	f	f	f	2026-03-03 05:25:26.939012
prog_fd8fb1d6	co_9e4115b3	1	t	f	f	f	f	f	2026-03-03 05:29:08.810863
prog_3dd53221	co_b7da8f92	1	t	f	f	f	f	f	2026-03-03 06:04:36.969116
prog_15b4120f	co_d52ef7a5	1	t	f	f	f	f	f	2026-03-26 15:55:34.793292
prog_8e8edfb4	co_f73de616	1	t	f	f	f	f	f	2026-03-27 21:31:23.434102
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscription_plans (id, name, description, price_monthly, price_yearly, max_invoices_per_month, max_users, max_pos_devices, allow_api_access, allow_branding, allow_multi_currency, priority_support, active, created_at, max_business_admins, max_finance_users) FROM stdin;
plan_free	Free	Start free with essential features	0	0	100	1	0	t	f	f	f	t	2025-10-24 18:05:23.738214	0	1
plan_starter	Starter	Perfect for small businesses	99	990	100	2	1	t	f	f	f	t	2025-10-24 18:05:23.967155	0	1
plan_professional	Professional	For growing businesses	299	2990	500	5	3	t	t	t	f	t	2025-10-24 18:05:24.19478	0	1
plan_enterprise	Enterprise	Unlimited for large organizations	999	9990	\N	50	10	t	t	t	t	t	2025-10-24 18:05:24.421878	0	1
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (id, company_id, tier, billing_cycle_months, monthly_price, discount_percent, status, stripe_subscription_id, stripe_customer_id, current_period_start, current_period_end, created_at, updated_at, cancelled_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, role, company_id, is_owner, full_name, invited_by, created_at, last_login, mfa_enabled, mfa_method, mfa_secret, mfa_backup_codes, mfa_enrolled_at, mfa_last_verified_at, must_change_password, password_changed_at, failed_login_attempts, locked_until, failed_login_count) FROM stdin;
user_e2e07904	test@test.com	$2b$12$Jhk.nVg3kULaHU6oAn.mkuEyw7NrMJzgHpGblvIYFFdlfQR0vB5.u	COMPANY_ADMIN	co_ecdeb90e	f	\N	\N	2025-10-25 09:22:50.437997	\N	f	\N	\N	\N	\N	\N	f	2025-10-25 09:22:50.437997	0	\N	0
user_b3562337	test2@gmail.com	$2b$12$028IVF6cz3Cs4oKuUUTz7.QmhABi/NTDJm.Ap78G5m6fsW24SEHqe	COMPANY_ADMIN	co_580c550f	t	Test2	\N	2025-10-25 11:27:30.932078	\N	f	\N	\N	\N	\N	\N	f	2025-10-25 11:27:30.932078	0	\N	0
usr_29fc7fbf8944	forcechgtest@involinks.test	$2b$12$vut1RkunGQ2lqUrnxTsfWOdcWgmwsF82zVyPWJVNoHx2OeNc3PSBa	FINANCE_USER	co_f73de616	f	Force Change Test	user_8ed5d4b2	2026-03-28 11:45:40.021695	2026-03-28 13:17:22.00632	f	\N	\N	\N	\N	\N	f	2026-03-28 11:45:40.021695	0	\N	0
user_aded05a574ec	nrashidk@gmail.com	$2b$12$vEijuEy.4nQ1JQcqoBbr0.IsSZQPX0uzQHJDYXpk3zeRBdIWGfuDi	SUPER_ADMIN	\N	f	\N	\N	2025-10-31 05:26:37.305282	2026-01-29 07:16:21.897138	f	\N	\N	\N	\N	\N	f	2025-10-31 05:26:37.305282	0	\N	3
user_4e48b14f	net@net.com	$2b$12$aMbS5x2qoY0QcpMSv7d3GOfAZ7C2ezpf6SyOvcGgBRT1xNXFERt6m	COMPANY_ADMIN	co_548156b4	t	Net	\N	2025-10-26 06:30:28.444075	\N	f	\N	\N	\N	\N	\N	f	2025-10-26 06:30:28.444075	0	\N	0
user_6e8ea078	test@n.com	$2b$12$.ZQwuOORc1XVI7WNP8V1Be51nlLZucUFJzSLixP/mfEAH.c/f0j2.	COMPANY_ADMIN	co_0afc5ba3	t	Nas	\N	2025-10-26 10:58:24.073965	\N	f	\N	\N	\N	\N	\N	f	2025-10-26 10:58:24.073965	0	\N	0
user_a83a0ce1	uae.n.me@gmail.com	$2b$12$saDbGTflXH31pLduxWcEC.hoCM4RXorzDsndWSoHGWq75EVfftme2	COMPANY_ADMIN	co_ef916725	t	Retro	\N	2025-10-26 17:50:25.289535	\N	f	\N	\N	\N	\N	\N	f	2025-10-26 17:50:25.289535	0	\N	0
user_0246096b	autotest1761592143@test.com	$2b$12$WpAkri6JHZ4vlrwOuyD5lOiOQkN0GgIHUb3Q.h4QTLJ/YFXEtAkgu	COMPANY_ADMIN	co_158975c0	t	AutoTest Company 1761592143	\N	2025-10-27 19:09:05.251642	\N	f	\N	\N	\N	\N	\N	f	2025-10-27 19:09:05.251642	0	\N	0
user_5f7fe526	newcompany@test.com	$2b$12$OgmjyXwe3A/HP7sp.PEIaucXv3CosOB1Mp1iyKJKpXOP0CYhhOgRe	COMPANY_ADMIN	co_ef6032c1	t	Test Company LLC	\N	2025-10-28 06:26:49.734663	2025-10-28 06:28:34.288142	t	totp	KUGFSUJZJW27K5FDAE3KAAVPAIL2JJEJ	["882a958128b7dba9953b72f44fd0bc432e7318ea9ab38d7c505ad6d657a1ee37", "4b02618c4db1206ba8d5be3b1c9d261397ef6d337805764df40068fefe3a78f2", "57390f205b1cd3115d94231c5be4ff22f73b88bf7e030bce8ad0bb0433e01070", "56e89ba2dc5c86abc329eecb082e371b525c1263e5364fc46f567ed2d42ede84", "f8918c374df9f182341d4f8ceee68a5e0dc3f58aff8ac6a7fc50ce28d2e1d842", "6d5c73b1829e523f492df61b211192e6c2137e9af23378ed62fc33193830ad4b", "a5a39f1ea41d7ede250ffab6cdceb41a3e431bee26d54927a13d441e89a28392", "fb0d0ba5965de664c75cf66704cfe6f6aa1b86dee01b851b141a246e984f12b8", "8370d675bdf2e8de034c0cc2c0791a555e80801d07d9558792c93853bdbe7e79", "a05da077a03ff094a9188daa33ae1bb8178c8fbf89c1e6b28e63f8eb9d4587e4"]	2025-10-28 06:29:20.529606	2025-10-28 06:29:20.529608	f	2025-10-28 06:26:49.734663	0	\N	0
user_09dcf4be	test@company.com	$2b$12$5cXMAjLobJTjGZNWqNPczee00ytsMWfLQJ8mByCA6wxV5SJtaPn3e	COMPANY_ADMIN	co_7e575f3d	t	Test Company LLC	\N	2025-10-28 08:05:16.550724	\N	f	\N	\N	\N	\N	\N	f	2025-10-28 08:05:16.550724	0	\N	0
user_f846d3d1	30oct@new.com	$2b$12$a6FX.khwvli6qsE7/IcZieT4aks2Pp4.YV2pahMMemusRW11.sIKy	COMPANY_ADMIN	co_35194978	t	New Test Company	\N	2025-10-30 03:55:24.301511	\N	f	\N	\N	\N	\N	\N	f	2025-10-30 03:55:24.301511	0	\N	0
user_ac1cc7fb	nrashidk+test@gmail.com	$2b$12$PykFFsZBvYJfqiYLDkgbL.PIGOUJxBix3.19L8jY.E4shq3ls2nwW	COMPANY_ADMIN	co_881c54ba	t	Test AWS SES	\N	2025-10-30 09:04:00.061293	\N	f	\N	\N	\N	\N	\N	f	2025-10-30 09:04:00.061293	0	\N	0
user_c60f93b2	n@nnn.com	$2b$12$xBNQwodZyd7syOZy./RjDemzTvQM.2ED2dRxt.wKswM8cJ7jtaopa	COMPANY_ADMIN	co_a0c89b23	t	Thursday LLC	\N	2025-10-30 17:23:06.822239	\N	f	\N	\N	\N	\N	\N	f	2025-10-30 17:23:06.822239	0	\N	0
user_8ed5d4b2	vattest@involinks.test	$2b$12$3JJeiPk.G4OdQy8fjuu7fuFCycTEarb251K2vN/.pk.MN/QwQl.1i	COMPANY_ADMIN	co_f73de616	t	VAT Test Co	\N	2026-03-27 21:31:23.432753	2026-03-28 19:54:31.476318	f	\N	\N	\N	\N	\N	f	2026-03-27 21:31:23.432753	0	\N	0
user_ca38e4a3	demo@business.com	$2b$12$OBzB426OqO31c2lev8cV0uSMlF.1mQwpefhe06CAfVqrq011M07h6	COMPANY_ADMIN	co_148bde71	f	\N	\N	2025-10-25 09:22:50.437997	\N	f	\N	\N	\N	\N	\N	f	2025-10-25 09:22:50.437997	0	\N	0
user_a3d72f30	testuser@involinks.ae	$2b$12$JjVibKqg7lncnNNe2EfdJeyrkYwusXPN.IRtReVH9RI82W3hOBTEy	COMPANY_ADMIN	co_d1297e64	t	E2E Test Company LLC	\N	2025-10-27 18:55:01.953748	2025-10-29 20:46:43.256248	t	totp	6LQR3X6G6TX4A2G2TIR4OMYE7MQCOT7T	["7f6a62de6f07bfbd309d534e6702f10dde0508242c6a8d98b8d4dcf61afb2e4b", "e36f1e2e22a5bbcfb43be3a27ccd6fb4211ce01522ca551ce6c5fc994109ea31", "53031305b6d4c53f2563f721058c0a1253639d19d71e5bb433816e1eeb8fbb6c", "bc831be95d9636d6ea31a79cb24f1a8d07239f8cbed60e0c4d05a0ed9d255d8e", "2329862750199c21dbb787e3ab04b04794bc18bb4dee8ace64f48dee3507eb08", "94b668c65b95f360d8464eb7ce13a1c3b1235df04d7effd6c7fe7f4cda35c64b", "5d17715fe75728d211fbdc201bbc71df0fcd300afe17b40d8b44de534b75e19c", "24710118665725b0643c69e30674c8ce4850a10d1b73b3b6c477afeafee4215f", "c5e8676840e8feeb6e156d0fc414fdf70fb9ed49a997603bee88b32f0bf07f48", "bae33991d2a83ee3995d85cc94fe107b4909de599c2ef097b23fcbd2b98fee7b"]	2025-10-28 06:03:05.195949	2025-10-29 20:46:43.256228	f	2025-10-27 18:55:01.953748	0	\N	0
user_599e1d88	retro_lounge@hotmail.com	$2b$12$lWPVNRIB8OsiWVdf1P6yIeaOS6kO0bg6jFzdrZ88ZsRnD0hMn2MCq	COMPANY_ADMIN	co_f69a4ff5	t	Test 31	\N	2025-10-31 05:44:18.239545	\N	f	\N	\N	\N	\N	\N	f	2025-10-31 05:44:18.239545	0	\N	0
user_7ffea5ad	namit10@yopmail.com	$2b$12$VZYNUvMYpt3R2jQaFOdBXerTOF1lzfbv/6FHsNV5Qwfa7g3UsdoT6	COMPANY_ADMIN	co_49d952ac	t	Namit	\N	2025-11-10 05:58:36.623446	2025-11-11 05:12:00.324236	t	totp	Q4KYV6354RP5CMO6QZPNS5IPEOLRCNAG	["ef17b2e7c55a93be9a7b77d815cba41f15207f92d341bef25a99e34c009b1600", "9e9be7a396b1d9eb7583999f682eb1b45192400a90eb9a4bfbb62bbdc64dd6eb", "eb24b482983cc69b1be636c018f0e69790ad2dc6a4b5c4b6e263ca0586d14f8d", "a3519b3700d04b2a3173fc97fe1f429da84f0641786cac51110437f9095eb9f8", "042686278fe08045d3dde690b8d7f70beda0c5a412d250a609721508c93cf524", "86658509f3e3b450246052089247846e3763c1ed12a133345c6ea0e9df3ca3c6", "e61c849dd9b3bad68085440d8eea281596e3a2b57e0c400a37ddcc85ac139fee", "d107ea6d314017094d1a93f5dcb704d4dda4702e523445f87874d99df2807614", "32800829bd2917db908830496a0feeca7600d5a7eb0d4e09a60a14917a700c17", "0ed1c0f4c971089ba32b5a7bd721b75882dffea07de322b401086515a33273c2"]	2025-11-10 10:21:50.807739	2025-11-11 05:12:00.324221	f	2025-11-10 05:58:36.623446	0	\N	0
user_1ba98fd7	namit.company@yopmail.com	$2b$12$i2GJcpXloRadkApk3lHeY.Zpm8rJbGPGMYq4Dbb7kL5neHz/LTWNm	COMPANY_ADMIN	co_5906d43b	t	Test Company	\N	2025-11-19 05:01:13.849125	2025-11-19 05:15:40.286698	f	\N	\N	\N	\N	\N	f	2025-11-19 05:01:13.849125	0	\N	0
usr_1e0856601205	test@yopmail.com	$2b$12$gViMev9cxb3kUfS.EPZ2.OtbuX4t4goDsFNnPLvZdlk5GqBuj9sLW	FINANCE_USER	co_43fc8468	f	test	user_6462f980	2026-02-04 05:24:17.402936	\N	f	\N	\N	\N	\N	\N	f	2026-02-04 05:24:17.402936	0	\N	0
user_b2b2ffae	test21@yopmail.com	$2b$12$Z6t5KinPyIbLFmW/nXyHk.xfXBvYKthZXn3.eYc3QlHFKbejb3eI2	COMPANY_ADMIN	co_9b3ade33	t	test	\N	2025-11-21 10:23:03.20228	\N	f	\N	\N	\N	\N	\N	f	2025-11-21 10:23:03.20228	0	\N	0
user_a20b853b	test12@gmail.com	$2b$12$UzqOQdupWumeSbY9zH8cWOsiY5OOd4lgOgHOWxseKn.7gTgOXMSLq	COMPANY_ADMIN	co_872df1f2	t	test	\N	2025-11-21 10:28:38.172598	\N	f	\N	\N	\N	\N	\N	f	2025-11-21 10:28:38.172598	0	\N	0
user_527be4e6	nn@nn.com	$2b$12$IPruQEySvjesW21GXHRwsOXRR3/aKLqqmnpmah3qSSj34LhUNgBoq	COMPANY_ADMIN	co_6e6acf00	t	Test 1	\N	2025-11-22 17:59:14.706246	\N	f	\N	\N	\N	\N	\N	f	2025-11-22 17:59:14.706246	0	\N	0
user_b8bbe48b	newtest@example.com	$2b$12$cXsjJOtPJn3O.uQeQCbzn.v5EwleW12baXYUR9TeO/IFGPervJDt2	COMPANY_ADMIN	co_016e80ee	t	New Test Co	\N	2025-10-31 22:39:38.424593	\N	f	\N	\N	\N	\N	\N	f	2025-10-31 22:39:38.424593	0	\N	0
user_4ce21191	namit.mcodeinfosoft@gmail.com	$2b$12$U54tTP43ghA9pIzO53iiUuMv4tcz11Uj4RhpSNl2ugBBMZ2bK2eby	COMPANY_ADMIN	co_43297d57	t	Mcode	\N	2025-11-21 10:26:21.974525	\N	f	\N	\N	\N	\N	\N	f	2025-11-21 10:26:21.974525	0	\N	0
user_6462f980	namittest@yopmail.com	$2b$12$TOYTkrHU2PTloXOYmVB6M.5nVapSFx9L.aBmg5Q75.TbfNmInK1Ae	COMPANY_ADMIN	co_43fc8468	t	Namit-code	\N	2025-11-21 07:16:43.663878	2026-03-24 06:25:28.801076	f	\N	\N	\N	\N	\N	f	2025-11-21 07:16:43.663878	0	\N	0
user_6fc795d0	200@test.com	$2b$12$kXGg5evhY9OFcaEjNCHT6u5VZAzT5X5bOyo.nqFCm8KIASyLbQwQy	COMPANY_ADMIN	co_d52ef7a5	t	200 test	\N	2026-03-26 15:55:34.790502	\N	f	\N	\N	\N	\N	\N	f	2026-03-26 15:55:34.790502	0	\N	0
usr_af449030e133	namitt@yopmail.com	$2b$12$I5lJtUXpphytxWry6H0t5uUvWj1SKj./KvlEkmv1buy8F8KbmqbR.	BUSINESS_ADMIN	co_43fc8468	f	test	user_6462f980	2026-02-25 05:29:21.628607	\N	f	\N	\N	\N	\N	\N	f	2026-02-25 05:29:21.628607	0	\N	0
user_41eed112	333333@test.com	$2b$12$8Leo8HI.3ZxbcsK3TBR8ouEkzuzFJfCu9kACWDPrqBF.BP8JjtWve	COMPANY_ADMIN	co_c6cb7ade	t	test	\N	2026-03-03 04:46:40.278723	\N	f	\N	\N	\N	\N	\N	f	2026-03-03 04:46:40.278723	0	\N	0
user_42a2befd	332333@test.com	$2b$12$BNlhPdOAK6fpXisbowjSu.SKUbqK58YciN3Rc7KSFw8Bllg.jhgFW	COMPANY_ADMIN	co_5de0fac6	t	test	\N	2026-03-03 04:47:31.540283	\N	f	\N	\N	\N	\N	\N	f	2026-03-03 04:47:31.540283	0	\N	0
user_6a1db992	3323333@test.com	$2b$12$MW.NMmqxhElT/uC9V02zXugFRdjces28Sn9nPfvNCETWgh0PMbFWC	COMPANY_ADMIN	co_09da6f57	t	test	\N	2026-03-03 05:25:26.937522	\N	f	\N	\N	\N	\N	\N	f	2026-03-03 05:25:26.937522	0	\N	0
user_58b13658	3354454@test.com	$2b$12$MnYX.yCbtMHl9l75Ztq2WO5xPA0AOYCG.VR1hMFObGwSw3wBsasCO	COMPANY_ADMIN	co_9e4115b3	t	test	\N	2026-03-03 05:29:08.809313	\N	f	\N	\N	\N	\N	\N	f	2026-03-03 05:29:08.809313	0	\N	0
user_fa60675e	test323323@yopmail.com	$2b$12$GHu6tEqI8gsbiVrPgtpSiOgeeEPC4VpnnGx7KydZcRVQq3jAgmpRW	COMPANY_ADMIN	co_b7da8f92	t	test	\N	2026-03-03 06:04:36.967768	\N	f	\N	\N	\N	\N	\N	f	2026-03-03 06:04:36.967768	0	\N	0
user_51e9013c	test@example.com	$2b$12$RT.KYJQ4Si6czT/eVFbkcOsCfUBhAwVcU9GbIvSdWOOIuEWb3HBX2	COMPANY_ADMIN	co_7b711239	f	\N	\N	2025-10-25 09:22:50.437997	\N	f	\N	\N	\N	\N	\N	f	2025-10-25 09:22:50.437997	0	\N	0
usr_13ce12ffa251	forced2@involinks.test	$2b$12$41x9HfgwBNkUfFU3dUat.uENDaJgGGf8SsI9FiO4XdnWk5LelQN8u	FINANCE_USER	co_f73de616	f	Forced Test 2	user_8ed5d4b2	2026-03-28 11:54:36.587801	2026-03-28 11:54:51.138661	f	\N	\N	\N	\N	\N	t	2026-03-28 11:54:36.587801	0	\N	0
usr_dcbb97f8307f	jwttest@involinks.test	$2b$12$Aif/mwLU80uUD2KkWiok5./LzojEUEX01G2NakejCPHFIoNOrRLHi	FINANCE_USER	co_f73de616	f	JWT Test	user_8ed5d4b2	2026-03-28 11:58:00.814698	2026-03-28 11:58:01.220212	f	\N	\N	\N	\N	\N	t	2026-03-28 11:58:00.814698	0	\N	0
user_60763c2b	namitsuper@yopmail.com	$2b$12$BNZj5nFx8gylobVnXEv89u1Y0qtq/EvsmMo5sp9XI7c8iNP24PugO	SUPER_ADMIN	\N	f	namit_test	\N	2026-02-02 06:33:27.075529	2026-03-28 20:04:15.390024	f	\N	\N	\N	\N	\N	f	2026-02-02 06:33:27.075529	0	\N	0
readonly-test-001	readonlytest@involinks.test	$2b$12$dwQibulTWk7kdSzkOWhcce7z6lx28DMh4AXVa1Fsbd/ujFcwccy8G	READ_ONLY	co_f73de616	f	\N	\N	2026-03-28 13:10:00.49977	2026-03-28 13:17:21.679478	f	\N	\N	\N	\N	\N	f	2026-03-28 13:10:00.49977	0	\N	0
\.


--
-- Data for Name: vat_returns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vat_returns (id, company_id, period_start, period_end, total_sales_invoices, total_purchase_invoices, standard_rated_sales, tax_refunds_provided, output_vat, standard_rated_purchases, purchase_expenses, input_vat_bills, input_vat_expenses, total_input_vat, net_vat_payable, generated_by_user_id, created_at, zero_rated_sales, exempt_sales, out_of_scope_sales, total_sales, zero_rated_purchases, exempt_purchases, reverse_charge_sales, reverse_charge_vat) FROM stdin;
vr_7dac9a8404e9	co_f73de616	2024-01-01	2025-03-31	0	0	0	0	0	0	0	0	0	0	0	user_8ed5d4b2	2026-03-27 21:33:11.755232	0	0	0	0	0	0	0	0
vr_fd5c3938b48c	co_f73de616	2026-03-01	2026-03-27	0	0	0	0	0	0	0	0	0	0	0	user_8ed5d4b2	2026-03-27 21:42:26.756571	0	0	0	0	0	0	0	0
vr_00b58c656680	co_f73de616	2026-03-01	2026-03-27	0	0	0	0	0	0	0	0	0	0	0	user_8ed5d4b2	2026-03-27 21:58:33.37814	0	0	0	0	0	0	0	0
vr_e5f23c1fc8b3	co_f73de616	2024-01-01	2025-03-31	0	0	0	0	0	0	0	0	0	0	0	user_8ed5d4b2	2026-03-27 22:12:08.057899	0	0	0	0	0	0	0	0
vr_05f15670026a	co_f73de616	2026-03-01	2026-03-27	0	0	0	0	0	0	0	0	0	0	0	user_8ed5d4b2	2026-03-27 22:13:24.008578	0	0	0	0	0	0	0	0
vr_9e26b1272b91	co_f73de616	2024-01-01	2024-12-31	0	0	0	0	0	0	0	0	0	0	0	user_8ed5d4b2	2026-03-27 22:18:52.776338	0	0	0	0	0	0	0	0
vr_27ad1b47c26a	co_f73de616	2024-01-01	2024-12-31	0	1	0	0	0	1200	0	60	0	60	-60	user_8ed5d4b2	2026-03-27 22:19:19.974382	0	0	0	0	500	300	0	10
vr_29219d079cb6	co_f73de616	2026-03-01	2026-03-27	0	0	0	0	0	0	0	0	0	0	0	user_8ed5d4b2	2026-03-27 22:20:28.878075	0	0	0	0	0	0	0	0
\.


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: audit_files audit_files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_files
    ADD CONSTRAINT audit_files_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_logs backup_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backup_logs
    ADD CONSTRAINT backup_logs_pkey PRIMARY KEY (id);


--
-- Name: billing_invoices billing_invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_invoices
    ADD CONSTRAINT billing_invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: billing_invoices billing_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_invoices
    ADD CONSTRAINT billing_invoices_pkey PRIMARY KEY (id);


--
-- Name: billing_invoices billing_invoices_stripe_invoice_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_invoices
    ADD CONSTRAINT billing_invoices_stripe_invoice_id_key UNIQUE (stripe_invoice_id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_branding company_branding_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_branding
    ADD CONSTRAINT company_branding_pkey PRIMARY KEY (id);


--
-- Name: company_documents company_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_documents
    ADD CONSTRAINT company_documents_pkey PRIMARY KEY (id);


--
-- Name: company_subscriptions company_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_subscriptions
    ADD CONSTRAINT company_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: content_blocks content_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_blocks
    ADD CONSTRAINT content_blocks_pkey PRIMARY KEY (id);


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: featured_businesses featured_businesses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.featured_businesses
    ADD CONSTRAINT featured_businesses_pkey PRIMARY KEY (id);


--
-- Name: goods_receipt_line_items goods_receipt_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods_receipt_line_items
    ADD CONSTRAINT goods_receipt_line_items_pkey PRIMARY KEY (id);


--
-- Name: goods_receipts goods_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT goods_receipts_pkey PRIMARY KEY (id);


--
-- Name: integrity_checks integrity_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrity_checks
    ADD CONSTRAINT integrity_checks_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: inventory_transactions inventory_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_pkey PRIMARY KEY (id);


--
-- Name: invoice_line_items invoice_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_tax_breakdowns invoice_tax_breakdowns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_tax_breakdowns
    ADD CONSTRAINT invoice_tax_breakdowns_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: inward_invoice_line_items inward_invoice_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoice_line_items
    ADD CONSTRAINT inward_invoice_line_items_pkey PRIMARY KEY (id);


--
-- Name: inward_invoices inward_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoices
    ADD CONSTRAINT inward_invoices_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_entry_lines journal_entry_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_pkey PRIMARY KEY (id);


--
-- Name: password_history password_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_history
    ADD CONSTRAINT password_history_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_stripe_payment_method_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_stripe_payment_method_id_key UNIQUE (stripe_payment_method_id);


--
-- Name: peppol_usage peppol_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peppol_usage
    ADD CONSTRAINT peppol_usage_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_line_items purchase_order_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order_line_items
    ADD CONSTRAINT purchase_order_line_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: registration_progress registration_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration_progress
    ADD CONSTRAINT registration_progress_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_stripe_subscription_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_stripe_subscription_id_key UNIQUE (stripe_subscription_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vat_returns vat_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vat_returns
    ADD CONSTRAINT vat_returns_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_log_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_log_company ON public.audit_log USING btree (company_id);


--
-- Name: idx_audit_log_entity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_log_entity ON public.audit_log USING btree (entity_type, entity_id);


--
-- Name: idx_audit_log_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_log_timestamp ON public.audit_log USING btree ("timestamp");


--
-- Name: idx_companies_trn; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_companies_trn ON public.companies USING btree (trn);


--
-- Name: idx_company_subs_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_company_subs_company ON public.company_subscriptions USING btree (company_id);


--
-- Name: idx_content_blocks_section; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_blocks_section ON public.content_blocks USING btree (section);


--
-- Name: idx_expenses_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_expenses_company ON public.expenses USING btree (company_id);


--
-- Name: idx_featured_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_featured_company ON public.featured_businesses USING btree (company_id);


--
-- Name: idx_grn_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_grn_company ON public.goods_receipts USING btree (company_id);


--
-- Name: idx_grn_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_grn_number ON public.goods_receipts USING btree (grn_number);


--
-- Name: idx_ili_invoice; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ili_invoice ON public.invoice_line_items USING btree (invoice_id);


--
-- Name: idx_inventory_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_company ON public.inventory_items USING btree (company_id);


--
-- Name: idx_invoices_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_company ON public.invoices USING btree (company_id);


--
-- Name: idx_invoices_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invoices_number ON public.invoices USING btree (invoice_number);


--
-- Name: idx_invtrx_item; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_invtrx_item ON public.inventory_transactions USING btree (inventory_item_id);


--
-- Name: idx_inward_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inward_company ON public.inward_invoices USING btree (company_id);


--
-- Name: idx_inward_supplier_invoice_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inward_supplier_invoice_number ON public.inward_invoices USING btree (supplier_invoice_number);


--
-- Name: idx_payment_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_payment_company ON public.payment_methods USING btree (company_id);


--
-- Name: idx_po_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_po_company ON public.purchase_orders USING btree (company_id);


--
-- Name: idx_po_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_po_number ON public.purchase_orders USING btree (po_number);


--
-- Name: idx_poli_po; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_poli_po ON public.purchase_order_line_items USING btree (po_id);


--
-- Name: ix_accounts_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_accounts_company_id ON public.accounts USING btree (company_id);


--
-- Name: ix_audit_files_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_files_company_id ON public.audit_files USING btree (company_id);


--
-- Name: ix_audit_log_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_company_id ON public.audit_log USING btree (company_id);


--
-- Name: ix_audit_log_entity_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_entity_id ON public.audit_log USING btree (entity_id);


--
-- Name: ix_audit_log_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_log_timestamp ON public.audit_log USING btree ("timestamp");


--
-- Name: ix_audit_logs_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_company_id ON public.audit_logs USING btree (company_id);


--
-- Name: ix_audit_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: ix_billing_invoices_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_billing_invoices_company_id ON public.billing_invoices USING btree (company_id);


--
-- Name: ix_company_branding_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_company_branding_company_id ON public.company_branding USING btree (company_id);


--
-- Name: ix_company_documents_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_company_documents_company_id ON public.company_documents USING btree (company_id);


--
-- Name: ix_company_subscriptions_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_company_subscriptions_company_id ON public.company_subscriptions USING btree (company_id);


--
-- Name: ix_content_blocks_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_content_blocks_key ON public.content_blocks USING btree (key);


--
-- Name: ix_content_blocks_section; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_content_blocks_section ON public.content_blocks USING btree (section);


--
-- Name: ix_expense_categories_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expense_categories_company_id ON public.expense_categories USING btree (company_id);


--
-- Name: ix_expenses_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_company_id ON public.expenses USING btree (company_id);


--
-- Name: ix_expenses_expense_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_expenses_expense_date ON public.expenses USING btree (expense_date);


--
-- Name: ix_featured_businesses_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_featured_businesses_company_id ON public.featured_businesses USING btree (company_id);


--
-- Name: ix_goods_receipt_line_items_grn_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_goods_receipt_line_items_grn_id ON public.goods_receipt_line_items USING btree (grn_id);


--
-- Name: ix_goods_receipts_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_goods_receipts_company_id ON public.goods_receipts USING btree (company_id);


--
-- Name: ix_goods_receipts_grn_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_goods_receipts_grn_number ON public.goods_receipts USING btree (grn_number);


--
-- Name: ix_goods_receipts_po_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_goods_receipts_po_id ON public.goods_receipts USING btree (po_id);


--
-- Name: ix_integrity_checks_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_integrity_checks_company_id ON public.integrity_checks USING btree (company_id);


--
-- Name: ix_inventory_items_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_items_company_id ON public.inventory_items USING btree (company_id);


--
-- Name: ix_inventory_items_item_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_items_item_code ON public.inventory_items USING btree (item_code);


--
-- Name: ix_inventory_transactions_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_transactions_company_id ON public.inventory_transactions USING btree (company_id);


--
-- Name: ix_inventory_transactions_inventory_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inventory_transactions_inventory_item_id ON public.inventory_transactions USING btree (inventory_item_id);


--
-- Name: ix_invoice_line_items_invoice_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_invoice_line_items_invoice_id ON public.invoice_line_items USING btree (invoice_id);


--
-- Name: ix_invoice_tax_breakdowns_invoice_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_invoice_tax_breakdowns_invoice_id ON public.invoice_tax_breakdowns USING btree (invoice_id);


--
-- Name: ix_invoices_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_invoices_company_id ON public.invoices USING btree (company_id);


--
-- Name: ix_invoices_invoice_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_invoices_invoice_number ON public.invoices USING btree (invoice_number);


--
-- Name: ix_invoices_share_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_invoices_share_token ON public.invoices USING btree (share_token);


--
-- Name: ix_inward_invoice_line_items_inward_invoice_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inward_invoice_line_items_inward_invoice_id ON public.inward_invoice_line_items USING btree (inward_invoice_id);


--
-- Name: ix_inward_invoices_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inward_invoices_company_id ON public.inward_invoices USING btree (company_id);


--
-- Name: ix_inward_invoices_grn_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inward_invoices_grn_id ON public.inward_invoices USING btree (grn_id);


--
-- Name: ix_inward_invoices_peppol_message_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inward_invoices_peppol_message_id ON public.inward_invoices USING btree (peppol_message_id);


--
-- Name: ix_inward_invoices_po_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inward_invoices_po_id ON public.inward_invoices USING btree (po_id);


--
-- Name: ix_inward_invoices_supplier_invoice_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_inward_invoices_supplier_invoice_number ON public.inward_invoices USING btree (supplier_invoice_number);


--
-- Name: ix_journal_entries_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_journal_entries_company_id ON public.journal_entries USING btree (company_id);


--
-- Name: ix_journal_entry_lines_journal_entry_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_journal_entry_lines_journal_entry_id ON public.journal_entry_lines USING btree (journal_entry_id);


--
-- Name: ix_password_history_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_password_history_user_id ON public.password_history USING btree (user_id);


--
-- Name: ix_payment_methods_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_payment_methods_company_id ON public.payment_methods USING btree (company_id);


--
-- Name: ix_peppol_usage_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_peppol_usage_company_id ON public.peppol_usage USING btree (company_id);


--
-- Name: ix_peppol_usage_month_year; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_peppol_usage_month_year ON public.peppol_usage USING btree (month_year);


--
-- Name: ix_purchase_order_line_items_po_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_purchase_order_line_items_po_id ON public.purchase_order_line_items USING btree (po_id);


--
-- Name: ix_purchase_orders_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_purchase_orders_company_id ON public.purchase_orders USING btree (company_id);


--
-- Name: ix_purchase_orders_po_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_purchase_orders_po_number ON public.purchase_orders USING btree (po_number);


--
-- Name: ix_registration_progress_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_registration_progress_company_id ON public.registration_progress USING btree (company_id);


--
-- Name: ix_subscriptions_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_subscriptions_company_id ON public.subscriptions USING btree (company_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_vat_returns_company_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_vat_returns_company_id ON public.vat_returns USING btree (company_id);


--
-- Name: accounts accounts_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: accounts accounts_parent_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_parent_account_id_fkey FOREIGN KEY (parent_account_id) REFERENCES public.accounts(id);


--
-- Name: audit_files audit_files_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_files
    ADD CONSTRAINT audit_files_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: audit_files audit_files_generated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_files
    ADD CONSTRAINT audit_files_generated_by_user_id_fkey FOREIGN KEY (generated_by_user_id) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_changed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_changed_by_user_id_fkey FOREIGN KEY (changed_by_user_id) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: audit_logs audit_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: billing_invoices billing_invoices_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_invoices
    ADD CONSTRAINT billing_invoices_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: billing_invoices billing_invoices_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.billing_invoices
    ADD CONSTRAINT billing_invoices_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- Name: company_branding company_branding_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_branding
    ADD CONSTRAINT company_branding_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: company_documents company_documents_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_documents
    ADD CONSTRAINT company_documents_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: company_subscriptions company_subscriptions_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_subscriptions
    ADD CONSTRAINT company_subscriptions_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: company_subscriptions company_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company_subscriptions
    ADD CONSTRAINT company_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.subscription_plans(id);


--
-- Name: expense_categories expense_categories_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expense_categories
    ADD CONSTRAINT expense_categories_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: expenses expenses_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: featured_businesses featured_businesses_added_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.featured_businesses
    ADD CONSTRAINT featured_businesses_added_by_user_id_fkey FOREIGN KEY (added_by_user_id) REFERENCES public.users(id);


--
-- Name: featured_businesses featured_businesses_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.featured_businesses
    ADD CONSTRAINT featured_businesses_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: goods_receipt_line_items goods_receipt_line_items_grn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods_receipt_line_items
    ADD CONSTRAINT goods_receipt_line_items_grn_id_fkey FOREIGN KEY (grn_id) REFERENCES public.goods_receipts(id);


--
-- Name: goods_receipt_line_items goods_receipt_line_items_po_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods_receipt_line_items
    ADD CONSTRAINT goods_receipt_line_items_po_line_item_id_fkey FOREIGN KEY (po_line_item_id) REFERENCES public.purchase_order_line_items(id);


--
-- Name: goods_receipts goods_receipts_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT goods_receipts_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: goods_receipts goods_receipts_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT goods_receipts_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_orders(id);


--
-- Name: goods_receipts goods_receipts_received_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods_receipts
    ADD CONSTRAINT goods_receipts_received_by_user_id_fkey FOREIGN KEY (received_by_user_id) REFERENCES public.users(id);


--
-- Name: integrity_checks integrity_checks_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrity_checks
    ADD CONSTRAINT integrity_checks_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: integrity_checks integrity_checks_performed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integrity_checks
    ADD CONSTRAINT integrity_checks_performed_by_user_id_fkey FOREIGN KEY (performed_by_user_id) REFERENCES public.users(id);


--
-- Name: inventory_items inventory_items_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: inventory_transactions inventory_transactions_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: inventory_transactions inventory_transactions_inventory_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_inventory_item_id_fkey FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_items(id);


--
-- Name: invoice_line_items invoice_line_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: invoice_tax_breakdowns invoice_tax_breakdowns_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_tax_breakdowns
    ADD CONSTRAINT invoice_tax_breakdowns_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: invoices invoices_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: invoices invoices_preceding_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_preceding_invoice_id_fkey FOREIGN KEY (preceding_invoice_id) REFERENCES public.invoices(id);


--
-- Name: inward_invoice_line_items inward_invoice_line_items_grn_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoice_line_items
    ADD CONSTRAINT inward_invoice_line_items_grn_line_item_id_fkey FOREIGN KEY (grn_line_item_id) REFERENCES public.goods_receipt_line_items(id);


--
-- Name: inward_invoice_line_items inward_invoice_line_items_inward_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoice_line_items
    ADD CONSTRAINT inward_invoice_line_items_inward_invoice_id_fkey FOREIGN KEY (inward_invoice_id) REFERENCES public.inward_invoices(id);


--
-- Name: inward_invoice_line_items inward_invoice_line_items_po_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoice_line_items
    ADD CONSTRAINT inward_invoice_line_items_po_line_item_id_fkey FOREIGN KEY (po_line_item_id) REFERENCES public.purchase_order_line_items(id);


--
-- Name: inward_invoices inward_invoices_approved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoices
    ADD CONSTRAINT inward_invoices_approved_by_user_id_fkey FOREIGN KEY (approved_by_user_id) REFERENCES public.users(id);


--
-- Name: inward_invoices inward_invoices_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoices
    ADD CONSTRAINT inward_invoices_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: inward_invoices inward_invoices_grn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoices
    ADD CONSTRAINT inward_invoices_grn_id_fkey FOREIGN KEY (grn_id) REFERENCES public.goods_receipts(id);


--
-- Name: inward_invoices inward_invoices_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoices
    ADD CONSTRAINT inward_invoices_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_orders(id);


--
-- Name: inward_invoices inward_invoices_reviewed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoices
    ADD CONSTRAINT inward_invoices_reviewed_by_user_id_fkey FOREIGN KEY (reviewed_by_user_id) REFERENCES public.users(id);


--
-- Name: inward_invoices inward_invoices_supplier_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inward_invoices
    ADD CONSTRAINT inward_invoices_supplier_company_id_fkey FOREIGN KEY (supplier_company_id) REFERENCES public.companies(id);


--
-- Name: journal_entries journal_entries_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: journal_entries journal_entries_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: journal_entry_lines journal_entry_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: journal_entry_lines journal_entry_lines_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id);


--
-- Name: password_history password_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_history
    ADD CONSTRAINT password_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payment_methods payment_methods_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: peppol_usage peppol_usage_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peppol_usage
    ADD CONSTRAINT peppol_usage_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: peppol_usage peppol_usage_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peppol_usage
    ADD CONSTRAINT peppol_usage_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: purchase_order_line_items purchase_order_line_items_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order_line_items
    ADD CONSTRAINT purchase_order_line_items_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_orders(id);


--
-- Name: purchase_orders purchase_orders_approved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_approved_by_user_id_fkey FOREIGN KEY (approved_by_user_id) REFERENCES public.users(id);


--
-- Name: purchase_orders purchase_orders_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: registration_progress registration_progress_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration_progress
    ADD CONSTRAINT registration_progress_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: subscriptions subscriptions_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: users users_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: users users_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: vat_returns vat_returns_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vat_returns
    ADD CONSTRAINT vat_returns_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: vat_returns vat_returns_generated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vat_returns
    ADD CONSTRAINT vat_returns_generated_by_user_id_fkey FOREIGN KEY (generated_by_user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict nGCWSXXidDUidE8Ep9ALzh8Q8nSB1bioRMiufJ9d7Avd5eNM3GjZdantNcgeH20

